Needed cflags

-fno-strict-aliasing
-Wno-format
