/* ========================================================================
 * Copyright (c) 2005-2010 The OPC Foundation, Inc. All rights reserved.
 *
 * OPC Foundation MIT License 1.00
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * The complete license agreement can be found here:
 * http://opcfoundation.org/License/MIT/1.00/
 * ======================================================================*/

#include "StdAfx.h"
#include "CTestServer.h"
#include "opcda_i.c"

#pragma warning(disable:4192)

//================================================================================
// COM Module Declarations

OPC_DECLARE_APPLICATION(ZPCSample, TestServer, "OPC ProxyStub Test Server")

OPC_BEGIN_CLASS_TABLE()
    OPC_CLASS_TABLE_ENTRY(CTestServer, TestServer, 1, "OPC ProxyStub Test Server")
OPC_END_CLASS_TABLE()

OPC_BEGIN_CATEGORY_TABLE()
    OPC_CATEGORY_TABLE_ENTRY(TestServer, CATID_OPCDAServer20, OPC_CATEGORY_DESCRIPTION_DA20)
    OPC_CATEGORY_TABLE_ENTRY(TestServer, CATID_OPCDAServer30, OPC_CATEGORY_DESCRIPTION_DA30)
OPC_END_CATEGORY_TABLE()

#ifndef _USRDLL

// {921CDFD6-EA59-425d-A9C6-D8456BD7BB0E}
OPC_IMPLEMENT_LOCAL_SERVER(0x921cdfd6, 0xea59, 0x425d, 0xa9, 0xc6, 0xd8, 0x45, 0x6b, 0xd7, 0xbb, 0xe);

//================================================================================
// WinMain

extern "C" int WINAPI _tWinMain(
    HINSTANCE hInstance, 
	HINSTANCE hPrevInstance, 
    LPTSTR    lpCmdLine, 
    int       nShowCmd
)
{
	MessageBox(0, lpCmdLine, 0, 0);
    OPC_START_LOCAL_SERVER_EX(hInstance, lpCmdLine);
    return 0;
}

#else

OPC_IMPLEMENT_INPROC_SERVER();

//==============================================================================
// DllMain

extern "C"
BOOL WINAPI DllMain( 
    HINSTANCE hModule, 
    DWORD     dwReason, 
    LPVOID    lpReserved)
{
    OPC_START_INPROC_SERVER(hModule, dwReason);
    return TRUE;
}

#endif // _USRDLL

//==============================================================================
// IOPCCommon

HRESULT CTestServer::SetLocaleID( 
    /* [in] */ LCID dwLcid)
{
	return S_OK;
}

HRESULT CTestServer::GetLocaleID( 
    /* [out] */ LCID *pdwLcid)
{
	*pdwLcid = 0;
	return S_OK;
}

HRESULT CTestServer::QueryAvailableLocaleIDs( 
	/* [out] */ DWORD *pdwCount,
	/* [size_is][size_is][out] */ LCID **pdwLcid)
{
	*pdwCount = 0;
	*pdwLcid = NULL;
	return S_OK;
}

HRESULT CTestServer::GetErrorString( 
    /* [in] */ HRESULT dwError,
    /* [string][out] */ LPWSTR *ppString)
{
	*ppString = NULL;
	return S_OK;
}

HRESULT CTestServer::SetClientName( 
    /* [string][in] */ LPCWSTR szName)
{
	return S_OK;
}
