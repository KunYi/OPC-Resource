// opctest.cpp
//
// (c) Copyright 1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Specifications and may be used
//  as set forth in the License Grant section of the OPC Specification.
//  This code is provided as-is and without warranty or support of any sort
//  and is subject to the Warranty and Liability Disclaimers which appear
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by
//  Al Chisholm, Intellution Inc.
//
// CONTENTS:
// This program tests the OPC Server Enumerator Object
// 
//
// Modification Log:
//	Vers    Date   By    Notes
//	----  -------- ---   -----
//       09/24/98 acc   
//

#include <stdio.h>
#include <conio.h>
#include "opccomn.h"	// Include the GENERIC OPC header file
//#include "opcda.h"	// Include the GENERIC OPC header file
#include "wcsutil.h"
#include "OLECTL.h"
#include "COMCAT.h"
#include "opccomn_i.c"	// Include the GENERIC OPC header file


//---------------------------------------------------------
// Local Functions

void LocalInit(void);
void LocalCleanup(void);

IOPCServerList * CreateRemoteOPCServer(CLSID &szProgID, WCHAR*szNodeName, IOPCServerList2 **pOPC2);
IOPCServerList * CreateLocalOPCServer(CLSID &szProgID, IOPCServerList2 **pOPC2);

void ShowDAList(CATID);

// Global interface to the COM memory manager
IMalloc *pIMalloc;


// Global list of available server interfaces
//
IOPCServerList *gpOPC = 0;
IOPCServerList2 *gpOPC2 = 0;

EXTERN_C const CLSID CLSID_OPCServerList;	//opcenum_clsid.c
EXTERN_C const IID IID_IOPCServerList;		//opccomn_i.c
EXTERN_C const IID IID_IOPCServerList2;		//opccomn_i.c

// Catagory IDs (in opcda_cats.c)
//
EXTERN_C const CATID CATID_OPCDAServer10;
EXTERN_C const CATID CATID_OPCDAServer20;
EXTERN_C const CATID CATID_OPCDAServer30;
EXTERN_C const CATID CATID_OPCHDAServer10;
EXTERN_C const CATID CATID_OPCAEServer10;

//---------------------------------------------------------
// _tWinMain
int main(int argc, CHAR* argv[])
{
	printf("OPC Server Browser Test Program V2.00\n");

	LocalInit();

	// Check for and show LOCAL registered Data Access Servers
	// using 'raw' component catagories
	//
//	printf("Checking Local DA 1.0 Servers using component catagories...\n");
//	ShowDAList(CATID_OPCDAServer10);
//	printf("Checking Local DA 2.0 Servers using component catagories...\n");
//	ShowDAList(CATID_OPCDAServer20);
//	printf("Checking Local DA 3.0 Servers using component catagories...\n");
//	ShowDAList(CATID_OPCDAServer30);
//	printf("Checking Local HDA 1.x Servers using component catagories...\n");
//	ShowDAList(CATID_OPCHDAServer10);
//	printf("Checking Local AE 1.x Servers using component catagories...\n");
//	ShowDAList(CATID_OPCAEServer10);

	// Now check again using OPCENUM.EXE ...
	//
	while(1)
	{
		CHAR c;
		CHAR buffer[82] = {80};
		CHAR *nptr, *pptr;
		WCHAR *node = 0;
		WCHAR *progid = 0;
		CLSID gkGuid = CLSID_OPCServerList;	// (from opcenum_i.c)

		printf("Preparing to test OPCENUM.EXE...\n");

		while(_kbhit())_getch();

		printf("Enter Server type: L(local), R(remote), P(progid), X(exit)\n");
		pptr = gets_s(buffer, 82);
		c = *pptr;
		if(c == 'x') break;
		if(c == 'X') break;

		// read the common info we need for all of the tests
		//

		while(_kbhit())_getch();
		switch(c)
		{

		case 'l':
		case 'L':
			gpOPC = CreateLocalOPCServer(gkGuid, &gpOPC2);
			break;

		case 'r':
		case 'R':
			printf("Enter Server NodeName\n");
			nptr = gets_s(buffer, 82);
			node = WSTRFromSBCS(nptr, 0);
		
			gpOPC = CreateRemoteOPCServer(gkGuid, node, &gpOPC2);
			break;

		case 'p':
		case 'P':
			printf("Enter Server NodeName\n");
			nptr = gets_s(buffer, 82);
			node = WSTRFromSBCS(nptr, 0);
		
			printf("Enter Prog ID\n");
			nptr = gets_s(buffer, 82);
			progid = WSTRFromSBCS(nptr, 0);
		
			gpOPC = CreateRemoteOPCServer(gkGuid, node, &gpOPC2);

			if (gpOPC) {
			  CLSID clsid;
			  HRESULT hr;

			  hr = gpOPC->CLSIDFromProgID(progid, &clsid);
			  if (FAILED(hr)) {
				printf("Remote CLSIDFromProgID(%ls) Failed (0x%x)\n", progid, hr);
			  } else {
				printf("Remote CLSIDFromProgID(%ls) Successful\n", progid);
			  }
			}

			if (gpOPC) {
			  gpOPC->Release();
			  gpOPC = NULL;
			}
			if (gpOPC2) {
			  gpOPC2->Release();
			  gpOPC2 = NULL;
			}

			WSTRFree(node, 0);
			node = 0;
			WSTRFree(progid, 0);
			progid = 0;
			break;

		default:
			break;
		}

		if(gpOPC)
//		if(gpOPC2)
		{
			HRESULT hr;
			IOPCEnumGUID *pOPCEnumGUID;
			IEnumGUID *pEnumGUID;
			CLSID catid;

			printf("\nGot the object...\n");
			// See what interfaces are supported


			// okay, so query for some DA 1.0 clsids
			catid = CATID_OPCDAServer10;
			hr = gpOPC->EnumClassesOfCategories(1, &catid, 1, &catid, &pEnumGUID); 
//			hr = gpOPC2->EnumClassesOfCategories(1, &catid, 1, &catid, &pOPCEnumGUID); 

			if (!FAILED(hr) && pEnumGUID != NULL) {	
//			if (!FAILED(hr) && pOPCEnumGUID != NULL) {	
			  unsigned long c;
			  CLSID clsid;
			
			  printf("\nOPC DA 1.0 Objects\n");
			  while (SUCCEEDED(hr = pEnumGUID->Next(1, &clsid, &c)))
//			  while (SUCCEEDED(hr = pOPCEnumGUID->Next(1, &clsid, &c)))
			  {
			   	LPOLESTR pszProgID=NULL;
				LPOLESTR pszUserType=NULL;
				HRESULT hr2 = gpOPC->GetClassDetails(clsid, &pszProgID, &pszUserType);
				LPOLESTR pszVendProgID=NULL;
//				HRESULT hr2 = gpOPC2->GetClassDetails(clsid, &pszProgID, &pszUserType, &pszVendProgID);
				if (FAILED(hr2))
				{
					hr = S_FALSE;
					break;
				}

				printf("ProgID = %ls, UserType = %ls\n", pszProgID, pszUserType);
//				printf("ProgID = %ls, UserType = %ls, Vendor = %ls\n", pszProgID, pszUserType, pszVendProgID);
					
				if (pszProgID != NULL) {
				  CoTaskMemFree(pszProgID);
				}
				if (pszUserType != NULL) {
				  CoTaskMemFree(pszUserType);
				}
				if (pszVendProgID != NULL) {
				  CoTaskMemFree(pszVendProgID);
				}
			  }

			  pEnumGUID->Release();
//			  pOPCEnumGUID->Release();

			} else {
			  printf("DA1: EnumClassesOfCategories - failed (%lx)\n", hr);
			}

			// okay, so query for some DA 2.0 clsids
			catid = CATID_OPCDAServer20;
			hr = gpOPC->EnumClassesOfCategories(1, &catid, 1, &catid, &pEnumGUID); 
//			hr = gpOPC2->EnumClassesOfCategories(1, &catid, 1, &catid, &pOPCEnumGUID); 

			if (!FAILED(hr) && pEnumGUID != NULL) {	
//			if (!FAILED(hr) && pOPCEnumGUID != NULL) {	
			  unsigned long c;
			  CLSID clsid;
			
			  printf("\nOPC DA 2.0 Objects\n");
			  while (SUCCEEDED(hr = pEnumGUID->Next(1, &clsid, &c)))
//			  while (SUCCEEDED(hr = pOPCEnumGUID->Next(1, &clsid, &c)))
			  {
			   	LPOLESTR pszProgID=NULL;
				LPOLESTR pszUserType=NULL;
				HRESULT hr2 = gpOPC->GetClassDetails(clsid, &pszProgID, &pszUserType);
				LPOLESTR pszVendProgID=NULL;
//				HRESULT hr2 = gpOPC2->GetClassDetails(clsid, &pszProgID, &pszUserType, &pszVendProgID);
				if (FAILED(hr2))
				{
					hr = S_FALSE;
					break;
				}

				printf("ProgID = %ls, UserType = %ls\n", pszProgID, pszUserType);
//				printf("ProgID = %ls, UserType = %ls, Vendor = %ls\n", pszProgID, pszUserType, pszVendProgID);
					
				if (pszProgID != NULL) {
				  CoTaskMemFree(pszProgID);
				}
				if (pszUserType != NULL) {
				  CoTaskMemFree(pszUserType);
				}
				if (pszVendProgID != NULL) {
				  CoTaskMemFree(pszVendProgID);
				}
			  }

			  pEnumGUID->Release();
//			  pOPCEnumGUID->Release();

			} else {
			  printf("DA2: EnumClassesOfCategories - failed (%lx)\n", hr);
			}

			if (gpOPC2) {
			  // okay, so query for some DA 3.0 clsids
			  catid = CATID_OPCDAServer30;
			  hr = gpOPC2->EnumClassesOfCategories(1, &catid, 1, &catid, &pOPCEnumGUID); 

			  if (!FAILED(hr) && pOPCEnumGUID != NULL) {	
			    unsigned long c;
			    CLSID clsid;
			
			    printf("\nOPC DA 3.0 Objects\n");
			    while (SUCCEEDED(hr = pOPCEnumGUID->Next(1, &clsid, &c)))
			    {
			   	  LPOLESTR pszProgID=NULL;
				  LPOLESTR pszUserType=NULL;
				  LPOLESTR pszVendProgID=NULL;
				  HRESULT hr2 = gpOPC2->GetClassDetails(clsid, &pszProgID, &pszUserType, &pszVendProgID);
				  if (FAILED(hr2))
				  {
					  hr = S_FALSE;
					  break;
				  }

				  printf("ProgID = %ls, UserType = %ls, Vendor = %ls\n", pszProgID, pszUserType, pszVendProgID);
					
				  if (pszProgID != NULL) {
				    CoTaskMemFree(pszProgID);
				  }
				  if (pszUserType != NULL) {
				    CoTaskMemFree(pszUserType);
				  }
				  if (pszVendProgID != NULL) {
				    CoTaskMemFree(pszVendProgID);
				  }
			    }

			    pOPCEnumGUID->Release();

			  } else {
			    printf("DA3: EnumClassesOfCategories - failed (%lx)\n", hr);
			  }

			  // okay, so query for some HDA 1.0 clsids
			  catid = CATID_OPCHDAServer10;
			  hr = gpOPC2->EnumClassesOfCategories(1, &catid, 1, &catid, &pOPCEnumGUID); 

			  if (!FAILED(hr) && pOPCEnumGUID != NULL) {	
			    unsigned long c;
			    CLSID clsid;
			
			    printf("\nOPC HDA 1.x Objects\n");
			    while (SUCCEEDED(hr = pOPCEnumGUID->Next(1, &clsid, &c)))
			    {
			   	  LPOLESTR pszProgID=NULL;
				  LPOLESTR pszUserType=NULL;
				  LPOLESTR pszVendProgID=NULL;
				  HRESULT hr2 = gpOPC2->GetClassDetails(clsid, &pszProgID, &pszUserType, &pszVendProgID);
				  if (FAILED(hr2))
				  {
					  hr = S_FALSE;
					  break;
				  }

				  printf("ProgID = %ls, UserType = %ls, Vendor = %ls\n", pszProgID, pszUserType, pszVendProgID);
					
				  if (pszProgID != NULL) {
				    CoTaskMemFree(pszProgID);
				  }
				  if (pszUserType != NULL) {
				    CoTaskMemFree(pszUserType);
				  }
				  if (pszVendProgID != NULL) {
				    CoTaskMemFree(pszVendProgID);
				  }
			    }

			    pOPCEnumGUID->Release();

			  } else {
			    printf("HDA: EnumClassesOfCategories - failed (%lx)\n", hr);
			  }
			} else {
			  // okay, so query for some HDA 1.0 clsids
			  catid = CATID_OPCHDAServer10;
			  hr = gpOPC->EnumClassesOfCategories(1, &catid, 1, &catid, &pEnumGUID); 

//			  if (!FAILED(hr) && pEnumGUID != NULL) {	
			  if (!FAILED(hr) && pOPCEnumGUID != NULL) {	
			    unsigned long c;
			    CLSID clsid;
			
			    printf("\nOPC HDA 1.x Objects\n");
//			    while (SUCCEEDED(hr = pEnumGUID->Next(1, &clsid, &c)))
			    while (SUCCEEDED(hr = pOPCEnumGUID->Next(1, &clsid, &c)))
			    {
			   	  LPOLESTR pszProgID=NULL;
				  LPOLESTR pszUserType=NULL;
//				  HRESULT hr2 = gpOPC->GetClassDetails(clsid, &pszProgID, &pszUserType);
				  LPOLESTR pszVendProgID=NULL;
				  HRESULT hr2 = gpOPC2->GetClassDetails(clsid, &pszProgID, &pszUserType, &pszVendProgID);
				  if (FAILED(hr2))
				  {
					  hr = S_FALSE;
					  break;
				  }

//				  printf("ProgID = %ls, UserType = %ls\n", pszProgID, pszUserType);
				  printf("ProgID = %ls, UserType = %ls, Vendor = %ls\n", pszProgID, pszUserType, pszVendProgID);
					
				  if (pszProgID != NULL) {
				    CoTaskMemFree(pszProgID);
				  }
				  if (pszUserType != NULL) {
				    CoTaskMemFree(pszUserType);
				  }
				  if (pszVendProgID != NULL) {
				    CoTaskMemFree(pszVendProgID);
				  }
			    }

//			    pEnumGUID->Release();
			    pOPCEnumGUID->Release();

			  } else {
			    printf("HDA: EnumClassesOfCategories - failed (%lx)\n", hr);
			  }
			}

			// okay, so query for some AE 1.0 clsids
			catid = CATID_OPCAEServer10;
//			hr = gpOPC->EnumClassesOfCategories(1, &catid, 1, &catid, &pEnumGUID); 
			hr = gpOPC2->EnumClassesOfCategories(1, &catid, 1, &catid, &pOPCEnumGUID); 

//			if (!FAILED(hr) && pEnumGUID != NULL) {	
			if (!FAILED(hr) && pOPCEnumGUID != NULL) {	
			  unsigned long c;
			  CLSID clsid;
			
			  printf("\nOPC AE 1.0 Objects\n");
//			  while (SUCCEEDED(hr = pEnumGUID->Next(1, &clsid, &c)))
			  while (SUCCEEDED(hr = pOPCEnumGUID->Next(1, &clsid, &c)))
			  {
			   	LPOLESTR pszProgID=NULL;
				LPOLESTR pszUserType=NULL;
//				HRESULT hr2 = gpOPC->GetClassDetails(clsid, &pszProgID, &pszUserType);
				LPOLESTR pszVendProgID=NULL;
				HRESULT hr2 = gpOPC2->GetClassDetails(clsid, &pszProgID, &pszUserType, &pszVendProgID);
				if (FAILED(hr2))
				{
					hr = S_FALSE;
					break;
				}

//				printf("ProgID = %ls, UserType = %ls\n", pszProgID, pszUserType);
				printf("ProgID = %ls, UserType = %ls, Vendor = %ls\n", pszProgID, pszUserType, pszVendProgID);
					
				if (pszProgID != NULL) {
				  CoTaskMemFree(pszProgID);
				}
				if (pszUserType != NULL) {
				  CoTaskMemFree(pszUserType);
				}
				if (pszVendProgID != NULL) {
				  CoTaskMemFree(pszVendProgID);
				}
			  }

//			  pEnumGUID->Release();
  			  pOPCEnumGUID->Release();

			} else {
			  printf("AE: EnumClassesOfCategories - failed (%lx)\n", hr);
			}

			printf("\n--end of list--\n");
		}


		// Free the interfaces
		//
		if(gpOPC) gpOPC->Release();

		WSTRFree(node, 0);
		node = 0;

	}

	LocalCleanup();

	printf("Done...\n");
	_getch();
	exit(0);
}




//---------------------------------------------------------
// LocalInit													z
// This is generic initialization for a task using COM
void LocalInit(void)
{
	HRESULT	r1;
	// General COM initialization...
	//
	r1 = CoInitializeEx(NULL, COINIT_MULTITHREADED);

	if (FAILED(r1))
	{
		printf("Error from CoInitializeEx(): 0x%08.8x\n", r1);
		exit(1);
	}
/*****
	// This is for DCOM
	//
	r1 = CoInitializeSecurity(
			NULL,   //Points to security descriptor 
			-1,     //Count of entries in asAuthSvc 
			NULL,   //Array of names to register 
			NULL,   //Reserved for future use 
			RPC_C_AUTHN_LEVEL_NONE,    //The default authentication level for proxies
			RPC_C_IMP_LEVEL_IMPERSONATE,//The default impersonation level for proxies
			NULL,                      //Reserved; must be set to  NULL 
			EOAC_NONE,                 //Additional client or server-side capabilities
			NULL                       //Reserved for future use 
			);

	if (FAILED(r1))
	{
		printf("Error from CoInitializeSecurity: %lx\n", r1);
//		CoUninitialize();
//		exit(1);
	}
*****/
	// Also get access to the COM memory manager
	//
	r1 = CoGetMalloc(MEMCTX_TASK, &pIMalloc);

	if (FAILED(r1))
	{
		printf("GetMalloc failed\n");
		CoUninitialize();
		exit(1);
	}
}

//---------------------------------------------------------
// LocalCleanup
// This is generic cleanup for any task using COM.
void LocalCleanup(void)
{
	// Finally, release the memory manager
	// as well as COM
	//
	pIMalloc->Release();
	CoUninitialize();
}


//---------------------------------------------------------
// CreateServer REMOTE
// Create the requested OPC Server - DCOM enabled!
IOPCServerList *CreateRemoteOPCServer(CLSID &clsid, WCHAR *szNodeName, IOPCServerList2 **pOPC2)
{
	HRESULT r2;
	MULTI_QI mqi;
	COSERVERINFO sin, *sinptr;
	DWORD clsctx;
	IOPCServerList *pOPC1=NULL;

	*pOPC2 = NULL;

	// set up server info
	//
	if(*szNodeName)
	{
        memset(&sin, 0, sizeof(COSERVERINFO));
		sinptr = &sin;
		sin.pwszName = szNodeName;
//		clsctx = CLSCTX_REMOTE_SERVER;
		clsctx = CLSCTX_SERVER;
	} else
	{
		// If NODE is Nul then try local server
		sinptr = 0;		// pointer should be NULL if local
		clsctx = CLSCTX_LOCAL_SERVER;
	}

	// set up mqi
	//
	mqi.pIID = &IID_IOPCServerList;
	mqi.hr = S_OK;
	mqi.pItf = NULL;

	// Note you must define _WIN32_DCOM in 'Settings'
	r2 = CoCreateInstanceEx(clsid, NULL, clsctx, sinptr, 1, &mqi);

	if (FAILED(r2) || FAILED(mqi.hr))
	{
		if (FAILED(r2)) {
		  printf("CoCreateInstanceEx - failed for node:%ls  (%lx)\n", szNodeName, r2);
		} else {
		  printf("CoCreateInstanceEx - failed for node:%ls  (%lx)\n", szNodeName, mqi.hr);
		}
		return NULL;
	}

	pOPC1 = (IOPCServerList*)mqi.pItf;

	// set up mqi
	//
	mqi.pIID = &IID_IOPCServerList;
	mqi.hr = S_OK;
	mqi.pItf = NULL;

	// Note you must define _WIN32_DCOM in 'Settings'
	r2 = CoCreateInstanceEx(clsid, NULL, clsctx, sinptr, 1, &mqi);

	if (FAILED(r2) || FAILED(mqi.hr))
	{
		if (FAILED(r2)) {
		  printf("CoCreateInstanceEx - failed for node:%ls  (%lx)\n", szNodeName, r2);
		} else {
		  printf("CoCreateInstanceEx - failed for node:%ls  (%lx)\n", szNodeName, mqi.hr);
		}
	} else {
	  *pOPC2 = (IOPCServerList2*)mqi.pItf;
	}

	printf("Remote Object Created \n");
	return(pOPC1);
}



//---------------------------------------------------------
// CreateServer LOCAL
// Create the requested OPC Server
IOPCServerList *CreateLocalOPCServer(CLSID&clsid, IOPCServerList2 **pOPC2)
{
	IClassFactory *pCF;
	HRESULT r2, r3;
	IOPCServerList * pOPC;

	*pOPC2 = NULL;

	// Create an OPC Sample Server Class Factory
	//
	r2 = CoGetClassObject(clsid, CLSCTX_LOCAL_SERVER , //try inproc first
		NULL, IID_IClassFactory, (void**)&pCF);

	if (FAILED(r2))
	{
		printf("CoGetClassObject Failed (%lx)\n", r2);
		printf("Are you sure you have registered OPCENUM.EXE?\n");
		return NULL;
	}

	// And use the class factory to create the OPC Server
	// Request an IUnknown Interface to it
	// and release the class factory which is no longer needed
	//
	r3 = pCF->CreateInstance(NULL, IID_IOPCServerList, (void**)&pOPC);

	if (FAILED(r3))
	{
		pCF->Release();
		printf("CreateInstance Failed (%lx)\n", r3);
		printf("Are you sure you have registered the latest OPCPROXY.DLL?\n");
		return NULL;
	}

	r3 = pCF->CreateInstance(NULL, IID_IOPCServerList2, (void**)pOPC2);

	pCF->Release();

	if (FAILED(r3))
	{
		printf("CreateInstance Failed (%lx)\n", r3);
		printf("Are you sure you have registered the latest OPCPROXY.DLL?\n");
		return NULL;
	}

	printf("Local Object Created\n");
	return pOPC;
}


