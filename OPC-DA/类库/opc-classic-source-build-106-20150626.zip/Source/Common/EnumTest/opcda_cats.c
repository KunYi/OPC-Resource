// 1/8/99 - acc - Fix Server20 CATID to have proper value

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __GUID_DEFINED__
#define __GUID_DEFINED__

typedef struct _GUID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} GUID;

#endif // __GUID_DEFINED__

// {63D5F430-CFE4-11d1-B2C8-0060083BA1FB}
const GUID CATID_OPCDAServer10 = 
{ 0x63d5f430, 0xcfe4, 0x11d1, { 0xb2, 0xc8, 0x0, 0x60, 0x8, 0x3b, 0xa1, 0xfb } };

// {63D5F432-CFE4-11d1-B2C8-0060083BA1FB}
const GUID CATID_OPCDAServer20 = 
{ 0x63d5f432, 0xcfe4, 0x11d1, { 0xb2, 0xc8, 0x0, 0x60, 0x8, 0x3b, 0xa1, 0xfb } };

// {CC603642-66D7-48F1-B69A-B625e73652d7}
const GUID CATID_OPCDAServer30 =
{ 0xCC603642, 0x66D7, 0x48f1, { 0xB6, 0x9A, 0xB6, 0x25, 0xE7, 0x36, 0x52, 0xD7 } };

// {7DE5B060-E089-11d2-A5E6-000086339399}
const GUID CATID_OPCHDAServer10 = 
{ 0x7de5b060, 0xe089, 0x11d2, { 0xa5, 0xe6, 0x0, 0x0, 0x86, 0x33, 0x93, 0x99 } };

// {58E13251-AC87-11D1-84D5-00608CB8A7E9}
const GUID CATID_OPCAEServer10 = 
{ 0x58e13251, 0xac87, 0x11d1, { 0x84, 0xd5, 0x00, 0x60, 0x8c, 0xb8, 0xa7, 0xe9 } };

#ifdef __cplusplus
}
#endif
