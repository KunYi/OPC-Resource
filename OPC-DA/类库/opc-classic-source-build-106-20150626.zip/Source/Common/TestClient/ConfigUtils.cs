/* ========================================================================
 * Copyright (c) 2005-2010 The OPC Foundation, Inc. All rights reserved.
 *
 * OPC Foundation MIT License 1.00
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * The complete license agreement can be found here:
 * http://opcfoundation.org/License/MIT/1.00/
 * ======================================================================*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Xml;
using System.Runtime.Serialization;
using System.Management;
using Microsoft.Win32;

namespace TestClient
{
    /// <summary>
    /// Utility functions used by COM applications.
    /// </summary>
    public static class ConfigUtils
    {
        /// <summary>
        /// Finds the first child element with the specified name.
        /// </summary>
        private static XmlElement FindFirstElement(XmlElement parent, string localName, string namespaceUri)
        {
            if (parent == null)
            {
                return null;
            }

            for (XmlNode child = parent.FirstChild; child != null; child = child.NextSibling)
            {
                XmlElement element = child as XmlElement;

                if (element != null)
                {
                    if (element.LocalName == localName && element.NamespaceURI == namespaceUri)
                    {
                        return element;
                    }

                    break;
                }
            }

            return null;
        }

		/// <summary>
		/// Registers the COM types in the specified assembly.
		/// </summary>
		public static List<System.Type> RegisterComTypes(string filePath)
		{
			// load assmebly.
			Assembly assembly = Assembly.LoadFrom(filePath);

			// check that the correct assembly is being registered.
			VerifyCodebase(assembly, filePath);

			RegistrationServices services = new RegistrationServices();

			// list types to register/unregister.
			List<System.Type> types = new List<System.Type>(services.GetRegistrableTypesInAssembly(assembly));

			// register types.
			if (types.Count > 0)
			{
				// unregister types first.	
				if (!services.UnregisterAssembly(assembly))
				{
					throw new ApplicationException("Unregister COM Types Failed.");
				}

				// register types.	
				if (!services.RegisterAssembly(assembly, AssemblyRegistrationFlags.SetCodeBase))
				{
					throw new ApplicationException("Register COM Types Failed.");
				}
			}

			return types;
		}

		/// <summary>
		/// Checks that the assembly loaded has the expected codebase.
		/// </summary>
		private static void VerifyCodebase(Assembly assembly, string filepath)
		{
			string codebase = assembly.CodeBase.ToLower();
			string normalizedPath = filepath.Replace('\\', '/').Replace("//", "/").ToLower();

			if (!normalizedPath.StartsWith("file:///"))
			{
				normalizedPath = "file:///" + normalizedPath;
			}

			if (codebase != normalizedPath)
			{
				throw new ApplicationException(String.Format("Duplicate assembly loaded. You need to restart the configuration tool.\r\n{0}\r\n{1}", codebase, normalizedPath));
			}
		}

		/// <summary>
		/// Unregisters the COM types in the specified assembly.
		/// </summary>
		public static List<System.Type> UnregisterComTypes(string filePath)
		{
			// load assmebly.
			Assembly assembly = Assembly.LoadFrom(filePath);

			// check that the correct assembly is being unregistered.
			VerifyCodebase(assembly, filePath);

			RegistrationServices services = new RegistrationServices();

			// list types to register/unregister.
			List<System.Type> types = new List<System.Type>(services.GetRegistrableTypesInAssembly(assembly));

			// unregister types.	
			if (!services.UnregisterAssembly(assembly))
			{
				throw new ApplicationException("Unregister COM Types Failed.");
			}

			return types;
		}
        
        /// <summary>
        /// Returns the name of the workgroup or domain that the computer belongs to.
        /// </summary>
        public static string GetComputerWorkgroupOrDomain() 
        {
            SelectQuery query = new SelectQuery("Win32_ComputerSystem");

            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);

            foreach (ManagementObject item in searcher.Get()) 
            {
                return item["Domain"] as string;
            }

            return null;
        }
        
		/// <summary>
		/// Returns the prog id from the clsid.
		/// </summary>
		public static string ProgIDFromCLSID(Guid clsid)
		{
			RegistryKey key = Registry.ClassesRoot.OpenSubKey(String.Format(@"CLSID\{{{0}}}\ProgId", clsid));
					
			if (key != null)
			{
				try
				{
					return key.GetValue("") as string;
				}
				finally
				{
					key.Close();
				}
			}

			return null;
		}

		/// <summary>
		/// Returns the prog id from the clsid.
		/// </summary>
		public static Guid CLSIDFromProgID(string progID)
		{
			if (String.IsNullOrEmpty(progID))
			{
				return Guid.Empty;
			}

			RegistryKey key = Registry.ClassesRoot.OpenSubKey(String.Format(@"{0}\CLSID", progID));
					
			if (key != null)
			{
				try
				{
					string clsid = key.GetValue(null) as string;

					if (clsid != null)
					{
						return new Guid(clsid.Substring(1, clsid.Length-2));
					}
				}
				finally
				{
					key.Close();
				}
			}

			return Guid.Empty;
		}
        
        
        /// <summary>
        /// Returns the implemented categories for the class.
        /// </summary>
        public static List<Guid> GetImplementedCategories(Guid clsid)
        {
            List<Guid> categories = new List<Guid>();

			string categoriesKey = String.Format(@"CLSID\{{{0}}}\Implemented Categories", clsid);
			
			RegistryKey key = Registry.ClassesRoot.OpenSubKey(categoriesKey);

			if (key != null)
			{
                try
                {
				    foreach (string catid in key.GetSubKeyNames())
				    {
                        try
                        {
                            Guid guid = new Guid(catid.Substring(1, catid.Length-2));
                            categories.Add(guid);
                        }
                        catch (Exception)
                        {
                            // ignore invalid keys.
                        }
				    }
                }
                finally
                {
                    key.Close();
                }
			}

            return categories;
        }

		/// <summary>
		/// Fetches the classes in the specified category.
		/// </summary>
		public static List<Guid> EnumClassesInCategory(Guid category)
		{
			ICatInformation manager = (ICatInformation)CreateServer(CLSID_StdComponentCategoriesMgr);
	
			object unknown = null;

			try
			{
				manager.EnumClassesOfCategories(
					1, 
					new Guid[] { category }, 
					0, 
					null,
					out unknown);
                
				IEnumGUID enumerator = (IEnumGUID)unknown;

				List<Guid> classes = new List<Guid>();

				Guid[] buffer = new Guid[10];

				while (true)
				{
					int fetched = 0;

                    IntPtr pGuids = Marshal.AllocCoTaskMem(Marshal.SizeOf(typeof(Guid))*buffer.Length);
                    
                    try
                    {
					    enumerator.Next(buffer.Length, pGuids, out fetched);

					    if (fetched == 0)
					    {
						    break;
					    }
                        
			            IntPtr pos = pGuids;

			            for (int ii = 0; ii < fetched; ii++)
			            {
				            buffer[ii] = (Guid)Marshal.PtrToStructure(pos, typeof(Guid));
				            pos = (IntPtr)(pos.ToInt64() + Marshal.SizeOf(typeof(Guid)));
			            }
                    }
                    finally
                    {
                        Marshal.FreeCoTaskMem(pGuids);
                    }

					for (int ii = 0; ii < fetched; ii++)
					{
						classes.Add(buffer[ii]);
					}
				}
			
				return classes;
			}
			finally
			{
				ReleaseServer(unknown);
				ReleaseServer(manager);
			}
        }

        /// <summary>
        /// The category identifier for UA servers that are registered as COM servers on a machine.
        /// </summary>
        public static readonly Guid CATID_PseudoComServers = new Guid("899A3076-F94E-4695-9DF8-0ED25B02BDBA");

        /// <summary>
        /// The CLSID for the UA COM DA server host process (note: will be eventually replaced the proxy server).
        /// </summary>
        public static readonly Guid CLSID_UaComDaProxyServer = new Guid("B25384BD-D0DD-4d4d-805C-6E9F309F27C1");

        /// <summary>
        /// The CLSID for the UA COM AE server host process (note: will be eventually replaced the proxy server).
        /// </summary>
        public static readonly Guid CLSID_UaComAeProxyServer = new Guid("4DF1784C-085A-403d-AF8A-B140639B10B3");

        /// <summary>
        /// The CLSID for the UA COM HDA server host process (note: will be eventually replaced the proxy server).
        /// </summary>
        public static readonly Guid CLSID_UaComHdaProxyServer = new Guid("2DA58B69-2D85-4de0-A934-7751322132E2");
        
        /// <summary>
        /// COM servers that support the DA 2.0 specification.
        /// </summary>
        public static readonly Guid CATID_OPCDAServer20  = new Guid("63D5F432-CFE4-11d1-B2C8-0060083BA1FB");

        /// <summary>
        /// COM servers that support the DA 3.0 specification.
        /// </summary>
        public static readonly Guid CATID_OPCDAServer30  = new Guid("CC603642-66D7-48f1-B69A-B625E73652D7");

        /// <summary>
        /// COM servers that support the AE 1.0 specification.
        /// </summary>
        public static readonly Guid CATID_OPCAEServer10  = new Guid("58E13251-AC87-11d1-84D5-00608CB8A7E9");

        /// <summary>
        /// COM servers that support the HDA 1.0 specification.
        /// </summary>
        public static readonly Guid CATID_OPCHDAServer10 = new Guid("7DE5B060-E089-11d2-A5E6-000086339399");

		/// <summary>
		/// Returns the location of the COM server executable.
		/// </summary>
		public static string GetExecutablePath(Guid clsid)
		{
			RegistryKey key = Registry.ClassesRoot.OpenSubKey(String.Format(@"CLSID\{{{0}}}\LocalServer32", clsid));

			if (key == null)
			{
				key	= Registry.ClassesRoot.OpenSubKey(String.Format(@"CLSID\{{{0}}}\InprocServer32", clsid));
			}

			if (key != null)
			{
				try
				{
					string codebase = key.GetValue("Codebase") as string;

					if (codebase == null)
					{
						return key.GetValue(null) as string;
					}

					return codebase;
				}
				finally
				{
					key.Close();
				}
			}

			return null;
		}

		/// <summary>
		/// Creates an instance of a COM server.
		/// </summary>
		public static object CreateServer(Guid clsid)
		{
			COSERVERINFO coserverInfo = new COSERVERINFO();

			coserverInfo.pwszName     = null;
			coserverInfo.pAuthInfo    = IntPtr.Zero;
			coserverInfo.dwReserved1  = 0;
			coserverInfo.dwReserved2  = 0;

			GCHandle hIID = GCHandle.Alloc(IID_IUnknown, GCHandleType.Pinned);

			MULTI_QI[] results = new MULTI_QI[1];

			results[0].iid  = hIID.AddrOfPinnedObject();
			results[0].pItf = null;
			results[0].hr   = 0;

			try
			{
				// create an instance.
				CoCreateInstanceEx(
					ref clsid,
					null,
					CLSCTX_INPROC_SERVER | CLSCTX_LOCAL_SERVER,
					ref coserverInfo,
					1,
					results);
			}
			finally
			{
				hIID.Free();
			}

			if (results[0].hr != 0)
			{
				throw new ExternalException("CoCreateInstanceEx: 0x{0:X8}" + results[0].hr);
			}

			return results[0].pItf;
		}

        /// <summary>
		/// Releases the server if it is a true COM server.
		/// </summary>
		public static void ReleaseServer(object server)
		{
			if (server != null && server.GetType().IsCOMObject)
			{
				Marshal.ReleaseComObject(server);
			}
		}
        
		/// <summary>
		/// Registers the classes in the specified category.
		/// </summary>
		public static void RegisterClassInCategory(Guid clsid, Guid catid)
		{
			RegisterClassInCategory(clsid, catid, null);
		}

		/// <summary>
		/// Registers the classes in the specified category.
		/// </summary>
		public static void RegisterClassInCategory(Guid clsid, Guid catid, string description)
		{
			ICatRegister manager = (ICatRegister)CreateServer(CLSID_StdComponentCategoriesMgr);
	
			try
			{
				string existingDescription = null;

				try
				{
					((ICatInformation)manager).GetCategoryDesc(catid, 0, out existingDescription);
				}
				catch (Exception e)
				{
					existingDescription = description;

					if (String.IsNullOrEmpty(existingDescription))
					{
						if (catid == CATID_OPCDAServer20)
						{
							existingDescription = CATID_OPCDAServer20_Description;
						}
						else if (catid == CATID_OPCDAServer30)
						{
							existingDescription = CATID_OPCDAServer30_Description;
						}
						else if (catid == CATID_OPCAEServer10)
						{
							existingDescription = CATID_OPCAEServer10_Description;
						}
						else if (catid == CATID_OPCHDAServer10)
						{
							existingDescription = CATID_OPCHDAServer10_Description;
						}
						else
						{
							throw new ApplicationException("No description for category available", e);
						}
					}

					CATEGORYINFO info;

					info.catid         = catid;
					info.lcid          = 0;
					info.szDescription = existingDescription;

					// register category.
					manager.RegisterCategories(1, new CATEGORYINFO[] { info });
				}

				// register class in category.
				manager.RegisterClassImplCategories(clsid, 1, new Guid[] { catid });
			}
			finally
			{
				ReleaseServer(manager);
			}
		}

        /// <summary>
        /// Removes the registration for a COM server from the registry.
        /// </summary>
        public static void UnregisterComServer(Guid clsid)
        {
			// unregister class in categories.
			string categoriesKey = String.Format(@"CLSID\{{{0}}}\Implemented Categories", clsid);
			
			RegistryKey key = Registry.ClassesRoot.OpenSubKey(categoriesKey);

			if (key != null)
			{
				try	  
				{ 
					foreach (string catid in key.GetSubKeyNames())
					{
						try	  
						{ 
							ConfigUtils.UnregisterClassInCategory(clsid, new Guid(catid.Substring(1, catid.Length-2)));
						}
						catch (Exception)
						{
							// ignore errors.
						}
					}
				}
				finally
				{
					key.Close();
				}
			}

			string progidKey = String.Format(@"CLSID\{{{0}}}\ProgId", clsid);

			// delete prog id.
			key = Registry.ClassesRoot.OpenSubKey(progidKey);
					
			if (key != null)
			{
				string progId = key.GetValue(null) as string;
				key.Close();

				if (!String.IsNullOrEmpty(progId))
				{
					try	  
					{ 
						Registry.ClassesRoot.DeleteSubKeyTree(progId); 
					}
					catch (Exception)
					{
						// ignore errors.
					}
				}
			}

			// delete clsid.
			try	  
			{ 
				Registry.ClassesRoot.DeleteSubKeyTree(String.Format(@"CLSID\{{{0}}}", clsid)); 
			}
			catch (Exception)
			{
				// ignore errors.
			}
        }

		/// <summary>
		/// Unregisters the classes in the specified category.
		/// </summary>
		public static void UnregisterClassInCategory(Guid clsid, Guid catid)
		{
			ICatRegister manager = (ICatRegister)CreateServer(CLSID_StdComponentCategoriesMgr);
	
			try
			{
				manager.UnRegisterClassImplCategories(clsid, 1, new Guid[] { catid });
			}
			finally
			{
				ReleaseServer(manager);
			}
		}

        #region COM Interop Declarations
		[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
		private struct COSERVERINFO
		{
			public uint         dwReserved1;
			[MarshalAs(UnmanagedType.LPWStr)]
			public string       pwszName;
			public IntPtr       pAuthInfo;
			public uint         dwReserved2;
		};

		[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
		private struct MULTI_QI
		{
			public IntPtr iid;
			[MarshalAs(UnmanagedType.IUnknown)]
			public object pItf;
			public uint   hr;
		}
		
		private const uint CLSCTX_INPROC_SERVER	 = 0x1;
		private const uint CLSCTX_INPROC_HANDLER = 0x2;
		private const uint CLSCTX_LOCAL_SERVER	 = 0x4;
		private const uint CLSCTX_REMOTE_SERVER	 = 0x10;

		private static readonly Guid IID_IUnknown = new Guid("00000000-0000-0000-C000-000000000046");
		
		[DllImport("ole32.dll")]
		private static extern void CoCreateInstanceEx(
			ref Guid         clsid,
			[MarshalAs(UnmanagedType.IUnknown)]
			object           punkOuter,
			uint             dwClsCtx,
			[In]
			ref COSERVERINFO pServerInfo,
			uint             dwCount,
			[In, Out]
			MULTI_QI[]       pResults);

	    [ComImport]
	    [GuidAttribute("0002E000-0000-0000-C000-000000000046")]
	    [InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)] 
        private interface IEnumGUID 
        {
            void Next(
		        [MarshalAs(UnmanagedType.I4)]
                int celt,
                [Out]
                IntPtr rgelt,
                [Out][MarshalAs(UnmanagedType.I4)]
                out int pceltFetched);

            void Skip(
		        [MarshalAs(UnmanagedType.I4)]
                int celt);

            void Reset();

            void Clone(
                [Out]
                out IEnumGUID ppenum);
        }

        [ComImport]
		[GuidAttribute("0002E013-0000-0000-C000-000000000046")]
		[InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)] 
		private interface ICatInformation
		{
			void EnumCategories( 
				int lcid,				
				[MarshalAs(UnmanagedType.Interface)]
				[Out] out object ppenumCategoryInfo);
        
			void GetCategoryDesc( 
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rcatid,
				int lcid,
				[MarshalAs(UnmanagedType.LPWStr)]
				[Out] out string pszDesc);
        
			void EnumClassesOfCategories( 
				int cImplemented,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=0)] 
				Guid[] rgcatidImpl,
				int cRequired,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=2)] 
				Guid[] rgcatidReq,
				[MarshalAs(UnmanagedType.Interface)]
				[Out] out object ppenumClsid);
        
			void IsClassOfCategories( 
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rclsid,
				int cImplemented,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=1)] 
				Guid[] rgcatidImpl,
				int cRequired,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=3)] 
				Guid[] rgcatidReq);
        
			void EnumImplCategoriesOfClass( 
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rclsid,
				[MarshalAs(UnmanagedType.Interface)]
				[Out] out object ppenumCatid);
        
			void EnumReqCategoriesOfClass(
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rclsid,
				[MarshalAs(UnmanagedType.Interface)]
				[Out] out object ppenumCatid);
		}

		[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
		struct CATEGORYINFO 
		{
			public Guid catid;
			public int lcid;
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=127)] 
			public string szDescription;
		}

		[ComImport]
		[GuidAttribute("0002E012-0000-0000-C000-000000000046")]
		[InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)] 
		private interface ICatRegister
		{
			void RegisterCategories(
				int cCategories,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=0)] 
				CATEGORYINFO[] rgCategoryInfo);

			void UnRegisterCategories(
				int cCategories,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=0)] 
				Guid[] rgcatid);

			void RegisterClassImplCategories(
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rclsid,
				int cCategories,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=1)] 
				Guid[] rgcatid);

			void UnRegisterClassImplCategories(
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rclsid,
				int cCategories,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=1)] 
				Guid[] rgcatid);

			void RegisterClassReqCategories(
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rclsid,
				int cCategories,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=1)] 
				Guid[] rgcatid);

			void UnRegisterClassReqCategories(
				[MarshalAs(UnmanagedType.LPStruct)] 
				Guid rclsid,
				int cCategories,
				[MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPStruct, SizeParamIndex=1)] 
				Guid[] rgcatid);
		}
        
        private static readonly Guid CLSID_StdComponentCategoriesMgr = new Guid("0002E005-0000-0000-C000-000000000046");

        private const string CATID_OPCDAServer20_Description  = "OPC Data Access Servers Version 2.0";
        private const string CATID_OPCDAServer30_Description  = "OPC Data Access Servers Version 3.0";
        private const string CATID_OPCAEServer10_Description  = "OPC Alarm & Event Server Version 1.0";
        private const string CATID_OPCHDAServer10_Description = "OPC History Data Access Servers Version 1.0";
        #endregion
        
        /// <summary>
        /// Registers the object ids required to access the certificate.
        /// </summary>
        public static void LocallyRegisterCertificateOIDs(X509Certificate2 certificate)
        {
            List<string> oids = new List<string>();
            oids.Add(certificate.PublicKey.Oid.Value);
            oids.Add(certificate.SignatureAlgorithm.Value);
            LocallyRegisterCertificateOIDs(oids.ToArray());
        }

        /// <summary>
        /// Registers the object ids required to access the certificate.
        /// </summary>
        /// <remarks>
        /// This function is used to work around a bug in .NET which results in long delays while OIDs are looked up in Active Directory.
        /// 
        /// CryptFindOIDInfo is supposed to work like this:
        /// 
        /// 1. A table of OID entries is constructed from registry entries with the CRYPT_INSTALL_OID_INFO_BEFORE_FLAG flag.  This table is searched first.
        /// 2. An internal table of OID entries is then searched. Default OIDs that Microsoft knows about.
        /// 3. A table of OIDs constructed from the registry entries without the CRYPT_INSTALL_OID_INFO_BEFORE_FLAG flag is then searched.
        /// 4. Active Directory is searched.        
        ///
        /// When registering the OID information with CryptRegisterOIDInfo(ptrInfo, 0) and hack the registry this is what will happen:
        /// 
        /// 1. Any application that searches for an OID (with the OID flag) will find it at step 2.  The OID will be correct as well as the friendly name since it uses CryptoAPI's internal table.
        /// 2. Any application that searches for a friendly name (with the friendly name flag) will find it as step 2.  The OID info is good as stated above.
        /// 3. .NET code which searches for an OID (with the friendly name flag) will find the entry in step 3 because of our hack.
        /// 4. Any OIDs that isn't found at this point will be searched in the Active Directory.
        /// 
        /// This code needs to be run once for each public key type.
        /// </remarks>
        public static void LocallyRegisterCertificateOIDs(string[] OIDs)
        {
            IntPtr pInfo;
            IntPtr pOID;

            RegistryKey key = null;
            CRYPT_OID_INFO oidInfo = new CRYPT_OID_INFO();

            for (int ii = 0; ii < OIDs.Length; ii++)
            {
                pOID = Marshal.StringToHGlobalAnsi(OIDs[ii]);
                pInfo = CryptFindOIDInfo(CRYPT_OID_INFO_OID_KEY, pOID, 0);
                Marshal.FreeHGlobal(pOID);

                if (pInfo != IntPtr.Zero)
                {
                    Marshal.PtrToStructure(pInfo, oidInfo);
                    
                    if (CryptRegisterOIDInfo(pInfo, CRYPT_INSTALL_OID_INFO_BEFORE_FLAG))
                    {
                        string strRegKey = 
                            "Software\\Microsoft\\Cryptography\\OID\\EncodingType 0\\CryptDllFindOIDInfo\\" 
                            + oidInfo.pszOID 
                            + "!" 
                            + oidInfo.dwGroupId.ToString();                        
                        
                        key = Registry.LocalMachine.CreateSubKey(strRegKey);
                        key.SetValue("Name", oidInfo.pszOID);
                        key.Close();            
                    }
                }
            }            
        }

        [DllImport("Crypt32.dll", EntryPoint = "CryptRegisterOIDInfo", CharSet = CharSet.Auto, SetLastError = true)]
        static extern Boolean CryptRegisterOIDInfo(IntPtr pInfo, Int32 dwFlags);

        [DllImport("Crypt32.dll", EntryPoint = "CryptFindOIDInfo", CharSet = CharSet.Auto, SetLastError = true)]
        static extern IntPtr CryptFindOIDInfo(Int32 dwKeyType, IntPtr pvKey, Int32 dwGroupId);

        private const Int32 CRYPT_OID_INFO_OID_KEY = 1;
        private const Int32  CRYPT_INSTALL_OID_INFO_BEFORE_FLAG  = 1;

        [StructLayout(LayoutKind.Sequential)]
        private class CRYPT_DATA_BLOB
        {
            public uint cbData;
            public IntPtr pbData;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private class CRYPT_OID_INFO
        {
            public UInt32 cbSize;
            [MarshalAs(UnmanagedType.LPStr)]
            public String pszOID;
            [MarshalAs(UnmanagedType.LPWStr)]
            public String pwszName;
            public UInt32 dwGroupId;
            public Int32 dwValue; // Use either dwValue or Algid or dwLen - they are a union
            // public UInt32 Algid;
            // public Int32 dwLength;
            public CRYPT_DATA_BLOB ExtraInfo;            
        };
    }
}
