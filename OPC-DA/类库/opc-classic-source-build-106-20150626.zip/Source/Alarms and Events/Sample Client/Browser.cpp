// Browser.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Browser.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 13 $
//       $Date: 9/14/02 8:55p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Browser.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Browser.cpp $
 * 
 * *****************  Version 13  *****************
 * User: Jiml         Date: 9/14/02    Time: 8:55p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 12  *****************
 * User: Jiml         Date: 11/18/98   Time: 4:28p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Trying for VC5 and VC6 compatibility
 * 
 * *****************  Version 11  *****************
 * User: Jiml         Date: 11/18/98   Time: 3:23p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Now Builds with VC 6.0
 * 
 * *****************  Version 10  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 9  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// Browser.cpp : implementation file
//

#include "stdafx.h"
#include "sampleclient.h"
#include "Browser.h"
#include "resource.h"


//included for error handling
#include "ErrorHandler.h"
#include "GlobalVar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define UNCHECKED 0
#define CHECKED 1


#define IMG_FOLDER	0
#define IMG_SOURCE	1
#define IMG_DISFOLDER 2
#define IMG_DISSOURCE 3


/////////////////////////////////////////////////////////////////////////////
// CBrowser dialog


CBrowser::CBrowser(IOPCEventServerPtr&  newIEventServer,OPCAEBROWSETYPE dwBrowseFilterType,CWnd* pParent /*=NULL*/)
	: CDialog(CBrowser::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBrowser)
	m_strArea = _T("");
	m_strSource = _T("");
	//}}AFX_DATA_INIT
	m_IEventServer = newIEventServer;
	m_IEventServer2 = m_IEventServer;  //  See if we can get the IEventServer2 Interface

	m_dwBrowseFilterType = dwBrowseFilterType;
}


void CBrowser::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBrowser)
	DDX_Control(pDX, IDC_FILTEREDIT, m_FilterEdit);
	DDX_Control(pDX, IDC_BROWSETREE, m_BrowseTree);
	DDX_Control(pDX, IDC_SOURCEEDIT, m_SourceEdit);
	DDX_Control(pDX, IDC_AREAEDIT, m_AreaEdit);
	DDX_Control(pDX, IDC_SOURCECHECK, m_SourceCheck);
	DDX_Control(pDX, IDC_AREACHECK, m_AreaCheck);
	DDX_Text(pDX, IDC_AREAEDIT, m_strArea);
	DDV_MaxChars(pDX, m_strArea, 255);
	DDX_Text(pDX, IDC_SOURCEEDIT, m_strSource);
	DDV_MaxChars(pDX, m_strSource, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBrowser, CDialog)
	//{{AFX_MSG_MAP(CBrowser)
	ON_BN_CLICKED(IDC_AREACHECK, OnAreacheck)
	ON_BN_CLICKED(IDC_SOURCECHECK, OnSourcecheck)
	ON_NOTIFY(NM_DBLCLK, IDC_BROWSETREE, OnDblclkBrowsetree)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBrowser message handlers



BOOL CBrowser::OnInitDialog() 
{
	USES_CONVERSION;

	CDialog::OnInitDialog();

	if(m_dwBrowseFilterType == OPC_AREA)
		m_AreaCheck.SetCheck(CHECKED);
	else
		m_AreaCheck.SetCheck(UNCHECKED);

	Togglecheck();

	LoadBitmaps();
	m_BrowseTree.SetImageList(&m_imageList, TVSIL_NORMAL);

	m_hFirstItem =NULL;	 //initialize first HTREEITEM

	// Fill the tree with the server's hierarchy
	HRESULT hr;
   
	ADDRIGHT(hr = m_IEventServer->CreateAreaBrowser( GUID_CAST(&__uuidof(m_IBrowse)),  
                           (IUnknown **)&m_IBrowse ));
	if(hr != S_OK)
		return TRUE;

	::IEnumStringPtr	IString;
	ADDRIGHT(hr=m_IBrowse->BrowseOPCAreas( OPC_AREA, L"*", &IString ));
	
	LPOLESTR lpoStr;
	LPWSTR szQName = NULL;

    if( hr == S_OK )
    {

		DWORD dwCount = 1;
		DWORD dwReturned = 0;

		for( hr = IString->Next( dwCount, &lpoStr, &dwReturned );dwReturned > 0;
			hr = IString->Next( dwCount, &lpoStr, &dwReturned )	)
		{

			ADDRIGHT(hr = m_IBrowse->GetQualifiedAreaName( lpoStr, &szQName ));

			if(hr==S_OK)
			{
				if(m_hFirstItem == NULL)
				{
					m_hFirstItem = InsertTreeItem(W2T(lpoStr),TVI_ROOT,OPC_AREA,szQName);
					InsertChildren( lpoStr, m_hFirstItem);
				}
				else
				{
					HTREEITEM item = InsertTreeItem(W2T(lpoStr),TVI_ROOT,OPC_AREA,szQName);
					InsertChildren( lpoStr, item);
				}
			}


			CoTaskMemFree( lpoStr );
			CoTaskMemFree( szQName );
		}

	}
	::IEnumStringPtr	IString2;
	//get all root level sources possible but unlikely
	ADDRIGHT(hr=m_IBrowse->BrowseOPCAreas( OPC_SOURCE, L"*", &IString2 ));
    if( hr == S_OK )
    {

		DWORD dwCount = 1;
		DWORD dwReturned = 0;


		for( hr = IString2->Next( dwCount, &lpoStr, &dwReturned );dwReturned > 0;			
			hr = IString2->Next( dwCount, &lpoStr, &dwReturned )	)
		{
			ADDRIGHT(hr = m_IBrowse->GetQualifiedSourceName( lpoStr, &szQName ));
			if(hr==S_OK)
				HTREEITEM item = InsertTreeItem(W2T(lpoStr),TVI_ROOT,OPC_SOURCE,szQName);

			CoTaskMemFree( lpoStr );
			CoTaskMemFree( szQName );

		}
	}

#if 0  //code to check the reference count of an smart pointer
	if(m_IBrowse.GetInterfacePtr() !=NULL)
	{
		ULONG temp = 0;
		temp = (m_IBrowse.GetInterfacePtr())->AddRef();
		temp = (m_IBrowse.GetInterfacePtr())->Release();
	}
	if(IString.GetInterfacePtr() !=NULL)
	{
		ULONG temp = 0;
		temp = (IString.GetInterfacePtr())->AddRef();
		temp = (IString.GetInterfacePtr())->Release();
	}
	if(IString2.GetInterfacePtr() !=NULL)
	{
		ULONG temp = 0;
		temp = (IString2.GetInterfacePtr())->AddRef();
		temp = (IString2.GetInterfacePtr())->Release();
	}
#endif

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CBrowser::LoadBitmaps()
{
	m_imageList.Create(16,16, TRUE, 4,4);

	int i=IDB_BITMAP3;
	CBitmap bm;
	if(bm.LoadBitmap(i))
	{
		m_imageList.Add(&bm, (COLORREF)0xFFFFFF);
		bm.DeleteObject();
	}

}

//**************************************************************************
// Recursive function that inserts all of the branches at this level
// and all of the children of each branch
void CBrowser::InsertChildren( LPWSTR child, HTREEITEM hParent)
{
	USES_CONVERSION;
	HRESULT hr;

	ADDRIGHT(hr = m_IBrowse->ChangeBrowsePosition( OPCAE_BROWSE_DOWN, (LPWSTR)child ));
    if( FAILED(hr) )
        return;

	::IEnumStringPtr	IString;
	ADDRIGHT(hr=m_IBrowse->BrowseOPCAreas( OPC_AREA, L"*", &IString ));

	LPOLESTR lpoStr;
	LPWSTR szQName = NULL;

    if( hr == S_OK )
    {

		DWORD dwCount = 1;
		DWORD dwReturned = 0;

		for( hr = IString->Next( dwCount, &lpoStr, &dwReturned );dwReturned > 0;
			hr = IString->Next( dwCount, &lpoStr, &dwReturned )	)
		{
			ADDRIGHT(hr = m_IBrowse->GetQualifiedAreaName( lpoStr, &szQName ));
			if(hr==S_OK)
			{
				HTREEITEM item = InsertTreeItem(W2T(lpoStr),hParent,OPC_AREA,szQName);
				InsertChildren( lpoStr, item);
			}
		
			CoTaskMemFree( lpoStr );
			CoTaskMemFree( szQName );

		}
	}

	::IEnumStringPtr	IString2;
	ADDRIGHT(hr=m_IBrowse->BrowseOPCAreas( OPC_SOURCE, L"*", &IString2 ));
    if( hr == S_OK )
    {

		DWORD dwCount = 1;
		DWORD dwReturned = 0;

		for( hr = IString2->Next( dwCount, &lpoStr, &dwReturned );dwReturned > 0;
			hr = IString2->Next( dwCount, &lpoStr, &dwReturned )	)
		{
			ADDRIGHT(hr = m_IBrowse->GetQualifiedSourceName( lpoStr, &szQName ));
			if(hr==S_OK)
				HTREEITEM item = InsertTreeItem(W2T(lpoStr),hParent,OPC_SOURCE,szQName);

			CoTaskMemFree( lpoStr );
			CoTaskMemFree( szQName );

		}
	}

	LPWSTR szTemp;
	szTemp = L"";
	ADDRIGHT(hr = m_IBrowse->ChangeBrowsePosition( OPCAE_BROWSE_UP, szTemp ));


}

HTREEITEM CBrowser::InsertTreeItem(LPCTSTR szText,HTREEITEM hParent,OPCAEBROWSETYPE dwBrowseFilterType,LPWSTR szQName)
{
	TV_INSERTSTRUCT Insert;
	CQualified* pQualified;
	HRESULT hr;
	LONG *pbEnabled = NULL;
	LONG *pbEffectivelyEnabled;
	HRESULT *pErrors = NULL;

	Insert.hParent = hParent;
	Insert.hInsertAfter = TVI_LAST;
	Insert.item.mask = TVIF_TEXT | TVIF_PARAM | TVIF_IMAGE | TVIF_SELECTEDIMAGE | 
						TVIF_CHILDREN | TVIF_STATE |TVIF_HANDLE;

	if(dwBrowseFilterType == OPC_AREA)
	{
		Insert.item.iImage         = IMG_FOLDER;
		Insert.item.iSelectedImage = IMG_FOLDER;
		Insert.item.cChildren = 1;
		if( m_IEventServer2 != NULL )
		{
			ADDRIGHT(hr = m_IEventServer2->GetEnableStateByArea( 1, &szQName, &pbEnabled, &pbEffectivelyEnabled, &pErrors ));
			if( SUCCEEDED(hr) )
			{
				if( SUCCEEDED( pErrors[0] ) )
				{
					if( !pbEnabled[0] )
					{
						Insert.item.iImage         = IMG_DISFOLDER;
						Insert.item.iSelectedImage = IMG_DISFOLDER;
					}
				}
				CoTaskMemFree( pErrors );
				CoTaskMemFree( pbEnabled );
				CoTaskMemFree( pbEffectivelyEnabled );
			}
		}
	}
	else
	{
		Insert.item.iImage         = IMG_SOURCE;
		Insert.item.iSelectedImage = IMG_SOURCE;
		Insert.item.cChildren = 0;
		if( m_IEventServer2 != NULL )
		{
			ADDRIGHT(hr = m_IEventServer2->GetEnableStateBySource( 1, &szQName, &pbEnabled, &pbEffectivelyEnabled, &pErrors ));
			if( SUCCEEDED(hr) )
			{
				if( SUCCEEDED( pErrors[0] ) )
				{
					if( !pbEnabled[0] )
					{
						Insert.item.iImage         = IMG_DISSOURCE;
						Insert.item.iSelectedImage = IMG_DISSOURCE;
					}
				}
				CoTaskMemFree( pErrors );
				CoTaskMemFree( pbEnabled );
				CoTaskMemFree( pbEffectivelyEnabled );
			}
		}
	}

    Insert.item.state &= ~TVIS_EXPANDEDONCE;
	Insert.item.stateMask = TVIS_EXPANDEDONCE;
	Insert.item.pszText = (LPTSTR)szText;
	Insert.item.cchTextMax = 255;

	pQualified = new CQualified;
	pQualified->m_dwBrowseFilterType = dwBrowseFilterType;
	pQualified->m_wszQualifiedName = szQName;

	(void *&)Insert.item.lParam = (void *)pQualified;
		
	HTREEITEM hItem = m_BrowseTree.InsertItem(&Insert);

	return hItem;
}

void CBrowser::OnOK() 
{
	FreePointers();
	CDialog::OnOK();
}

void CBrowser::OnAreacheck() 
{
	Togglecheck();
}

void CBrowser::OnSourcecheck() 
{
	Togglecheck();
}

void CBrowser::Togglecheck() 
{
	if(	m_AreaCheck.GetCheck()==CHECKED)
	{
		m_AreaCheck.SetCheck(CHECKED);
		m_SourceCheck.SetCheck(UNCHECKED);

		m_AreaEdit.SetReadOnly(FALSE);
		m_SourceEdit.SetReadOnly(TRUE);
	}
	else
	{
		m_AreaCheck.SetCheck(UNCHECKED);
		m_SourceCheck.SetCheck(CHECKED);

		m_AreaEdit.SetReadOnly(TRUE);
		m_SourceEdit.SetReadOnly(FALSE);
	}
}

void CBrowser::OnDblclkBrowsetree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	USES_CONVERSION;
	CQualified* pQualified;

	LPNMTREEVIEW ptree = (LPNMTREEVIEW)pNMHDR;

	HTREEITEM hItem = m_BrowseTree.GetSelectedItem();

	pQualified = (CQualified *)m_BrowseTree.GetItemData(hItem);
	if(pQualified->m_dwBrowseFilterType == OPC_AREA)
		m_AreaEdit.SetWindowText(W2T(pQualified->m_wszQualifiedName.c_str()));
	else
		m_SourceEdit.SetWindowText(W2T(pQualified->m_wszQualifiedName.c_str()));

	
	*pResult = 0;
}

void CBrowser::DeleteChildItem(HTREEITEM hItem)
{
	CQualified* pQualified;

	//CString temp = m_BrowseTree.GetItemText(hItem); //for debug
	
	while(m_BrowseTree.ItemHasChildren(hItem))  
	{
		HTREEITEM hChildItem = m_BrowseTree.GetChildItem(hItem);
		if(hChildItem != NULL)
		{
			DeleteChildItem(hChildItem);
			//delete Child items after children of child items have been deleted
			//if delete fails break
			pQualified = (CQualified *)m_BrowseTree.GetItemData(hChildItem);
			delete pQualified;
			if(!m_BrowseTree.DeleteItem(hChildItem))
				break;
		}
		else
			break;  //if the child items cannot be resolved assume that they have been removed
	}

}

void CBrowser::StartDeleteChildItem(HTREEITEM hItem)
{
	if(hItem ==NULL)
		return;
			
	DeleteChildItem(hItem);  //delete all child items of root

	HTREEITEM hSibItem = m_BrowseTree.GetNextSiblingItem(hItem);

	if(hItem != NULL)  //delete root items
	{
		CQualified* pQualified;

		pQualified = (CQualified *)m_BrowseTree.GetItemData(hItem);
		delete pQualified;
		if(!m_BrowseTree.DeleteItem(hItem))
				return;
	}

	StartDeleteChildItem(hSibItem);
	
}

void CBrowser::OnDestroy() 
{
	StartDeleteChildItem(m_hFirstItem);
	CDialog::OnDestroy();
}

void CBrowser::FreePointers()
{
	m_IBrowse.Attach(NULL);
	m_IEventServer.Attach(NULL);  
}

void CBrowser::OnCancel() 
{
	FreePointers();	
	CDialog::OnCancel();
}
