// EventSub.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: EventSub.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 7 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/EventSub.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: EventSub.h $
 * 
 * *****************  Version 7  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#if !defined(AFX_EVENTSUB_H__CBDE4735_C7E0_11D1_9E05_00608CB8A6B0__INCLUDED_)
#define AFX_EVENTSUB_H__CBDE4735_C7E0_11D1_9E05_00608CB8A6B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// EventSub.h : header file
//

#pragma warning( disable : 4786 )


/////////////////////////////////////////////////////////////////////////////
// CEventSub dialog

class CEventSub : public CDialog
{
// Construction
public:
	CEventSub(IOPCEventServerPtr&  newIEventServer,IOPCEventSubscriptionMgtPtr& newISubMgt,CWnd* pParent = NULL);   // standard constructor
	DWORD TexttoDWORD(CEdit& edit);
	void DWORDtoText(CEdit& edit,DWORD dwValue);
	void OnExecute();


	IOPCEventSubscriptionMgtPtr m_ISubMgt;
	CComObject<COPCEventSink>   *m_pSink;
	BOOL m_bNewSubscription;
	DWORD m_dwCookie;  //sink cookie


// Dialog Data
	//{{AFX_DATA(CEventSub)
	enum { IDD = IDD_EVENTSUB };
	CButton	m_NullCheck;
	CButton	m_ActiveCheck;
	CEdit	m_MaxSize;
	CEdit	m_ClientSub;
	CEdit	m_BufferTime;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEventSub)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	IOPCEventServerPtr m_IEventServer;

	// Generated message map functions
	//{{AFX_MSG(CEventSub)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnApplybutton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EVENTSUB_H__CBDE4735_C7E0_11D1_9E05_00608CB8A6B0__INCLUDED_)
