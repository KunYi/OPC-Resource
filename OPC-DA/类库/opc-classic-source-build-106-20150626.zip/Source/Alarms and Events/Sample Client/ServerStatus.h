// ServerStatus.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: ServerStatus.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 3 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/ServerStatus.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: ServerStatus.h $
 * 
 * *****************  Version 3  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 2  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#if !defined(AFX_SERVERSTATUS_H__76067995_BE74_11D1_9E03_00608CB8A6B0__INCLUDED_)
#define AFX_SERVERSTATUS_H__76067995_BE74_11D1_9E03_00608CB8A6B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ServerStatus.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CServerStatus dialog

class CServerStatus : public CDialog
{
// Construction
public:
	CServerStatus(IOPCEventServerPtr& newEventServerPtr,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CServerStatus)
	enum { IDD = IDD_SERVERSTAT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerStatus)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	IOPCEventServerPtr m_IEventServer;

	// Generated message map functions
	//{{AFX_MSG(CServerStatus)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERSTATUS_H__76067995_BE74_11D1_9E03_00608CB8A6B0__INCLUDED_)
