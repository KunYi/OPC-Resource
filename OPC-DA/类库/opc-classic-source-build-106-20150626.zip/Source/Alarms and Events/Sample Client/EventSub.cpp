// EventSub.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: EventSub.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 10 $
//       $Date: 12/08/02 3:54p $
//    $Archive: /OPC/AlarmEvents/SampleClient/EventSub.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: EventSub.cpp $
 * 
 * *****************  Version 10  *****************
 * User: Jiml         Date: 12/08/02   Time: 3:54p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Added keep-alive
 * 
 * *****************  Version 9  *****************
 * User: Jiml         Date: 8/04/99    Time: 6:48p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 8  *****************
 * User: Jiml         Date: 11/18/98   Time: 4:28p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Trying for VC5 and VC6 compatibility
 * 
 * *****************  Version 7  *****************
 * User: Jiml         Date: 11/18/98   Time: 3:23p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Now Builds with VC 6.0
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// EventSub.cpp : implementation file
//

#include "stdafx.h"
#include "sampleclient.h"
#include "OPCEventSink.h"
#include "EventSub.h"

//included for error handling
#include "ErrorHandler.h"
#include "GlobalVar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define UNCHECKED 0
#define CHECKED 1

/////////////////////////////////////////////////////////////////////////////
// CEventSub dialog


CEventSub::CEventSub(IOPCEventServerPtr&  newIEventServer,IOPCEventSubscriptionMgtPtr& newISubMgt,
	CWnd* pParent /*=NULL*/): CDialog(CEventSub::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEventSub)
	//}}AFX_DATA_INIT

	m_bNewSubscription = 1;
	m_IEventServer = newIEventServer;
	m_ISubMgt=NULL;
	if(newISubMgt != NULL)  //every = to a valid location increaments the ref count
	{
		m_bNewSubscription = 0;
		m_ISubMgt=newISubMgt;
	}
}


void CEventSub::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEventSub)
	DDX_Control(pDX, IDC_NULLCHECK, m_NullCheck);
	DDX_Control(pDX, IDC_ACTIVECHECK, m_ActiveCheck);
	DDX_Control(pDX, IDC_MAXSIZEEDIT, m_MaxSize);
	DDX_Control(pDX, IDC_CLIENTEDIT, m_ClientSub);
	DDX_Control(pDX, IDC_BUFFERTIMEEDIT, m_BufferTime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEventSub, CDialog)
	//{{AFX_MSG_MAP(CEventSub)
	ON_BN_CLICKED(IDC_APPLYBUTTON, OnApplybutton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEventSub message handlers

void CEventSub::OnOK() 
{

	OnExecute();
	CDialog::OnOK();

}

void CEventSub::OnExecute() 
{
	HRESULT hr;
	long bActive;
	DWORD dwBufferTime;
	DWORD dwMaxSize;
	DWORD hClientSubscription;
	DWORD dwRevisedBufferTime;
	DWORD dwRevisedMaxSize;

	bActive=m_ActiveCheck.GetCheck();
	dwBufferTime = TexttoDWORD(m_BufferTime);
	dwMaxSize = TexttoDWORD(m_MaxSize);  

#if 0  //server should check for maxsize of 0 however client should never pass it
	if(!dwMaxSize)
	{
		dwMaxSize=1;
		DWORDtoText(m_MaxSize,dwMaxSize);
	}
#endif

	hClientSubscription = TexttoDWORD(m_ClientSub);

	if(m_bNewSubscription)
	{
		ADDRIGHT(hr = m_IEventServer->CreateEventSubscription( bActive,
							dwBufferTime,
							dwMaxSize,
							hClientSubscription,
							GUID_CAST(&__uuidof(m_ISubMgt)),  
                           (IUnknown **)&m_ISubMgt,
						   &dwRevisedBufferTime,
						   &dwRevisedMaxSize ));

		if(hr!=S_OK)
		{
			MessageBox("Fialed to Create Subscription");
			return;
		}

		// create advise
		CComObject<COPCEventSink>::CreateInstance(&m_pSink);
		m_dwCookie = 99;

		IUnknownPtr pUnk;
		m_pSink->_InternalQueryInterface( __uuidof(IUnknown), (void**)&pUnk );

		ADDRIGHT(hr = AtlAdvise( m_ISubMgt, pUnk,__uuidof(IOPCEventSink), &m_dwCookie ));

	}
	else
	{
		if(m_NullCheck.GetCheck())  //for testing purposes
		{
			long *pbActive;
			DWORD *pdwBufferTime;
			DWORD *pdwMaxSize;
			pbActive=NULL;	
			pdwBufferTime = NULL;
			pdwMaxSize = NULL;

			ADDRIGHT(hr=m_ISubMgt->SetState(pbActive,pdwBufferTime,pdwMaxSize,
				hClientSubscription,&dwRevisedBufferTime,&dwRevisedMaxSize));
		}
		else
			ADDRIGHT(hr=m_ISubMgt->SetState(&bActive,&dwBufferTime,&dwMaxSize,
				hClientSubscription,&dwRevisedBufferTime,&dwRevisedMaxSize));
		



		if(hr!=S_OK)
		{
			MessageBox("Fialed to Set State");
			return;
		}
	}

	if(dwRevisedBufferTime!=dwBufferTime)
		DWORDtoText(m_BufferTime,dwRevisedBufferTime);

	if(dwRevisedMaxSize!=dwMaxSize)
		DWORDtoText(m_MaxSize,dwRevisedMaxSize);


	IOPCEventSubscriptionMgt2Ptr ISubMgt2 = m_ISubMgt;
	if( ISubMgt2 != NULL )
	{
		DWORD dwRevisedKeepAliveTime = 0;
		// set the keep-alive to 3X the dwRevisedBufferTime
		ADDRIGHT(hr=ISubMgt2->SetKeepAlive( 3 * dwRevisedBufferTime, &dwRevisedKeepAliveTime ));
	}
}


BOOL CEventSub::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString strText;

	if(m_bNewSubscription)  //new subscription
	{
		//initialize to this
		DWORDtoText(m_ClientSub,(DWORD)this);
		DWORDtoText(m_BufferTime,10000);
		DWORDtoText(m_MaxSize,1000);

		return TRUE;
	}

	HRESULT hr;
	long bActive;
	DWORD dwBufferTime;
	DWORD dwMaxSixe;
	DWORD hClientSubscription;


	ADDRIGHT(hr=m_ISubMgt->GetState(&bActive,&dwBufferTime,&dwMaxSixe,&hClientSubscription));

	if(hr==S_OK)
	{
		if(bActive)
			m_ActiveCheck.SetCheck(CHECKED);

		DWORDtoText(m_ClientSub,(DWORD)hClientSubscription);
		DWORDtoText(m_BufferTime,dwBufferTime);
		DWORDtoText(m_MaxSize,dwMaxSixe);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

DWORD CEventSub::TexttoDWORD(CEdit& edit)
{
	USES_CONVERSION;

	CString strText;
	WCHAR *w=L" ";

	edit.GetWindowText(strText);
	return wcstoul(T2W((LPCTSTR)strText),&w,10);
}
	

void CEventSub::DWORDtoText(CEdit& edit,DWORD dwValue)
{
	USES_CONVERSION;
	CString strText;
	WCHAR w[11];

	_ultow(dwValue,w,10);
	strText=W2T(w);
	edit.SetWindowText(strText);
}


void CEventSub::OnApplybutton() 
{
	OnExecute();
}
