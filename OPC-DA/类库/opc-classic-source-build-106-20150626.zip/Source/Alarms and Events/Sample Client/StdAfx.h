// StdAfx.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: StdAfx.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 13 $
//       $Date: 11/20/98 11:48a $
//    $Archive: /OPC/AlarmEvents/SampleClient/StdAfx.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: StdAfx.h $
 * 
 * *****************  Version 13  *****************
 * User: Jiml         Date: 11/20/98   Time: 11:48a
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 12  *****************
 * User: Jiml         Date: 11/18/98   Time: 4:28p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Trying for VC5 and VC6 compatibility
 * 
 * *****************  Version 11  *****************
 * User: Jiml         Date: 11/18/98   Time: 3:23p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Now Builds with VC 6.0
 * 
 * *****************  Version 10  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 9  *****************
 * User: Jiml         Date: 5/19/98    Time: 5:27p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * No longer crashes the compiller when compiled under 95!
 * 
 * *****************  Version 8  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__81824B1B_821A_11D1_84BB_00608CB8A7E9__INCLUDED_)
#define AFX_STDAFX_H__81824B1B_821A_11D1_84BB_00608CB8A7E9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define WINVER 0x0400

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#include <afxwin.h>         // MFC core and standard components
#include <comcat.h>
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC OLE automation classes
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <atlbase.h>
extern CComModule _Module;
#include <atlcom.h>

#include <afxcview.h>       // MFC support for CListView

#import "opc_aeps.dll" exclude("_FILETIME","IEnumString")
using namespace OPC_AE;

#import "opccomn_ps.dll" exclude("_FILETIME","IEnumGUID", "IEnumCLSID", "IEnumString", "IEnumUnknown", "IConnectionPoint", "IConnectionPointContainer", "IEnumConnectionPoints", "IEnumConnections", "tagCONNECTDATA")
using namespace OPCCOMN;

#include "opcaedef.h"

#if _MSC_VER > 1100  // VC 6.0 and higher
	#define GUID_CAST( a )		(const_cast<_GUID*>(a))
#else				// VC 5.0
	#define GUID_CAST( a )		((struct GUID *)a)
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__81824B1B_821A_11D1_84BB_00608CB8A7E9__INCLUDED_)
