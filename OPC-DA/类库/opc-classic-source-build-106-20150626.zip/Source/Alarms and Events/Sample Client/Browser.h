// Browser.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Browser.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 9 $
//       $Date: 9/14/02 8:55p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Browser.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Browser.h $
 * 
 * *****************  Version 9  *****************
 * User: Jiml         Date: 9/14/02    Time: 8:55p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 8  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 7  *****************
 * User: Jiml         Date: 5/19/98    Time: 5:27p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * No longer crashes the compiller when compiled under 95!
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#if !defined(AFX_BROWSER_H__60A09144_C008_11D1_9E04_00608CB8A6B0__INCLUDED_)
#define AFX_BROWSER_H__60A09144_C008_11D1_9E04_00608CB8A6B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Browser.h : header file
//


#include <string> 
using namespace std;


class CQualified
{
public:
	OPCAEBROWSETYPE m_dwBrowseFilterType;
	wstring m_wszQualifiedName;
};

/////////////////////////////////////////////////////////////////////////////
// CBrowser dialog

class CBrowser : public CDialog
{
// Construction
public:
	CBrowser(IOPCEventServerPtr&  newIEventServer,OPCAEBROWSETYPE dwBrowseFilterType = OPC_AREA,CWnd* pParent = NULL);   // standard constructor
	void InsertChildren( LPWSTR child, HTREEITEM hParent);
	void Togglecheck() ;
	HTREEITEM InsertTreeItem(LPCTSTR szText,HTREEITEM hParent,OPCAEBROWSETYPE dwBrowseFilterType,LPWSTR szQName);
	void LoadBitmaps();
	void DeleteChildItem(HTREEITEM hItem);
	void StartDeleteChildItem(HTREEITEM hItem);
	void FreePointers();

		
	// Dialog Data
	//{{AFX_DATA(CBrowser)
	enum { IDD = IDD_BROWSER };
	CEdit	m_FilterEdit;
	CTreeCtrl	m_BrowseTree;
	CEdit	m_SourceEdit;
	CEdit	m_AreaEdit;
	CButton	m_SourceCheck;
	CButton	m_AreaCheck;
	CString	m_strArea;
	CString	m_strSource;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBrowser)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	IOPCEventServerPtr		m_IEventServer;
	IOPCEventAreaBrowserPtr	m_IBrowse;
	IOPCEventServer2Ptr		m_IEventServer2;

	CImageList m_imageList;
	
	HTREEITEM m_hFirstItem;
	OPCAEBROWSETYPE m_dwBrowseFilterType;

	// Generated message map functions
	//{{AFX_MSG(CBrowser)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnAreacheck();
	afx_msg void OnSourcecheck();
	afx_msg void OnDblclkBrowsetree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#define BMINDEX(x)      (x - IDB_BITMAP1)


#endif // !defined(AFX_BROWSER_H__60A09144_C008_11D1_9E04_00608CB8A6B0__INCLUDED_)
