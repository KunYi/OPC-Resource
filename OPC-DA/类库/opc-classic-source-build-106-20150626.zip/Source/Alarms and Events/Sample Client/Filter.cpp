// Filter.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Filter.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 13 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Filter.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Filter.cpp $
 * 
 * *****************  Version 13  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 12  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// Filter.cpp : implementation file
//

#include "stdafx.h"
#include "sampleclient.h"
#include "Filter.h"
#include "Browser.h"

//included for error handling
#include "ErrorHandler.h"
#include "GlobalVar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilter dialog
CFilter::CFilter(IOPCEventServerPtr& newIEventServer, IOPCEventSubscriptionMgtPtr& newISubMgt,
 CWnd* pParent /*=NULL*/): CDialog(CFilter::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFilter)
	//}}AFX_DATA_INIT

	m_IEventServer = newIEventServer;
	m_ISubMgt = newISubMgt;
}



void CFilter::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFilter)
	DDX_Control(pDX, IDC_EVENTLIST2, m_EventList2);
	DDX_Control(pDX, IDC_TRACKCHECK, m_TracCheck);
	DDX_Control(pDX, IDC_BREMSOURCE, m_RemSource);
	DDX_Control(pDX, IDC_BREMEVENT, m_RemEvent);
	DDX_Control(pDX, IDC_BREMAREA, m_RemArea);
	DDX_Control(pDX, IDC_BADDSOURCE, m_AddSource);
	DDX_Control(pDX, IDC_BADDEVENT, m_AddEvent);
	DDX_Control(pDX, IDC_BADDAREA, m_AddArea);
	DDX_Control(pDX, IDC_SIMPCHECK, m_SimpCheck);
	DDX_Control(pDX, IDC_SOURCELIST, m_SourceList);
	DDX_Control(pDX, IDC_LOWSEVEDIT, m_LowSev);
	DDX_Control(pDX, IDC_HIGHSEVEDIT, m_HighSev);
	DDX_Control(pDX, IDC_EVENTLIST, m_EventList);
	DDX_Control(pDX, IDC_CONDCHECK, m_CondCheck);
	DDX_Control(pDX, IDC_AREALIST, m_AreaList);
	DDX_Control(pDX, IDC_ALLCHECK, m_AllCheck);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFilter, CDialog)
	//{{AFX_MSG_MAP(CFilter)
	ON_BN_CLICKED(IDC_ALLCHECK, OnAllcheck)
	ON_BN_CLICKED(IDC_CONDCHECK, OnCondcheck)
	ON_BN_CLICKED(IDC_SIMPCHECK, OnSimpcheck)
	ON_BN_CLICKED(IDC_TRACKCHECK, OnTrackcheck)
	ON_BN_CLICKED(IDC_BADDAREA, OnBaddarea)
	ON_BN_CLICKED(IDC_BADDEVENT, OnBaddevent)
	ON_BN_CLICKED(IDC_BADDSOURCE, OnBaddsource)
	ON_BN_CLICKED(IDC_BREMAREA, OnBremarea)
	ON_BN_CLICKED(IDC_BREMEVENT, OnBremevent)
	ON_BN_CLICKED(IDC_BREMSOURCE, OnBremsource)
	ON_NOTIFY(LVN_BEGINLABELEDIT, IDC_AREALIST, OnBeginlabeleditArealist)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_AREALIST, OnEndlabeleditArealist)
	ON_NOTIFY(LVN_BEGINLABELEDIT, IDC_SOURCELIST, OnBeginlabeleditSourcelist)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_SOURCELIST, OnEndlabeleditSourcelist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilter message handlers
#define UNCHECKED 0
#define CHECKED 1

///////////////////////////////////////////
// Event Type support
///////////////////////////////////////////
void CFilter::OnAllcheck() 
{
	if(m_AllCheck.GetCheck() == UNCHECKED)
	{
		m_AllCheck.SetCheck(UNCHECKED);
		m_CondCheck.EnableWindow(TRUE);
		m_SimpCheck.EnableWindow(TRUE);
		m_TracCheck.EnableWindow(TRUE);
	}
	else
	{
		m_AllCheck.SetCheck(CHECKED);
		m_CondCheck.EnableWindow(FALSE);
		m_SimpCheck.EnableWindow(FALSE);
		m_TracCheck.EnableWindow(FALSE);
	}
}

void CFilter::OnCondcheck() 
{
	OnThreeCheck();
}

void CFilter::OnSimpcheck() 
{
	OnThreeCheck();
}

void CFilter::OnTrackcheck() 
{
	OnThreeCheck();
}

void CFilter::OnThreeCheck()
{
	if((m_CondCheck.GetCheck() == CHECKED)&&(m_SimpCheck.GetCheck() == CHECKED)
		&&(m_TracCheck.GetCheck() == CHECKED))
	{
		m_AllCheck.SetCheck(CHECKED);
		m_CondCheck.SetCheck(UNCHECKED);
		m_SimpCheck.SetCheck(UNCHECKED);
		m_TracCheck.SetCheck(UNCHECKED);
		m_CondCheck.EnableWindow(FALSE);
		m_SimpCheck.EnableWindow(FALSE);
		m_TracCheck.EnableWindow(FALSE);
	}
}

void CFilter::SetEventType()
{
	m_dwEventType =0;
	if(m_AllCheck.GetCheck() == CHECKED)
	{
		m_dwEventType = OPC_ALL_EVENTS;
		return;
	}
	if(m_CondCheck.GetCheck() == CHECKED)
		m_dwEventType |= OPC_CONDITION_EVENT;
	if(m_SimpCheck.GetCheck() == CHECKED)
		m_dwEventType |= OPC_SIMPLE_EVENT;
	if(m_TracCheck.GetCheck() == CHECKED)
		m_dwEventType |= OPC_TRACKING_EVENT;
	
}

void CFilter::GetEventType()
{
	if((m_dwEventType & OPC_ALL_EVENTS) == OPC_ALL_EVENTS)
	{
		m_AllCheck.SetCheck(CHECKED);
		OnAllcheck();
		return;
	}
	if(m_dwEventType & OPC_CONDITION_EVENT)
		m_CondCheck.SetCheck(CHECKED);
		
	if(m_dwEventType & OPC_SIMPLE_EVENT)
		m_SimpCheck.SetCheck(CHECKED);
		
	if(m_dwEventType & OPC_TRACKING_EVENT)
		m_TracCheck.SetCheck(CHECKED);
		
}

///////////////////////////////////////////
// Event Category support
///////////////////////////////////////////

void CFilter::OnBaddevent() 
{
	int item = 0;
	CString strText;
	DWORD dwEvent;

	UINT count = m_EventList2.GetSelCount();

	//checks to see if any items are selected
	if(count == 0||count == LB_ERR)
		return;

	//gets total size of list
	count =	m_EventList2.GetCount();
	if(count == LB_ERR)
		return;

	for(UINT i = 0;i< count;i++)
	{
		item = m_EventList2.GetSel(i);
		if(item == LB_ERR)
			return;
		else if(item)
		{
			m_EventList2.GetText(i,strText);
			dwEvent=m_EventList2.GetItemData(i);

			// no duplicates allowed
			if( m_EventList.FindStringExact( 0, strText ) == LB_ERR )
			{
				item = m_EventList.AddString(strText);
				if(item == LB_ERR)
					return;
				item = m_EventList.SetItemData(item,dwEvent);
				if(item == LB_ERR)
					return;
			}
		}
		
	}
	
}

void CFilter::OnBremevent() 
{
	int item = 0;
	UINT count = m_EventList.GetSelCount();

	//checks to see if any items are selected
	if(count == 0||count == LB_ERR)
		return;

	//gets total size of list
	count =	m_EventList.GetCount();
	if(count == LB_ERR)
		return;

	//needs to remove from the end
	for(UINT i = count-1;i >= 0;i--)
	{
		item = m_EventList.GetSel(i);
		if(item == LB_ERR)  //this will ensure a break from the loop when the number rounds
			return;
		else if(item)
			m_EventList.DeleteString(i);
	}
	
}

void CFilter::OnInitEventList2()
{
	USES_CONVERSION;

	HRESULT hr;

	DWORD *pdwEventCategories = NULL;;
	LPWSTR *pszDescs = NULL;
	DWORD dwCount = 0;
	int item;

	// QueryEventCategories
	ADDRIGHT(hr = m_IEventServer->QueryEventCategories( OPC_ALL_EVENTS, 
							&dwCount, &pdwEventCategories, &pszDescs ));
	if(hr != S_OK)
		return;

	for( DWORD i = 0; i < dwCount; i++ )
	{
		CString strText(W2T(pszDescs[i]));

		item = m_EventList2.AddString(strText);
		item = m_EventList2.SetItemData(item,pdwEventCategories[i]);
		
		CoTaskMemFree( pszDescs[i] );
	}
	
	CoTaskMemFree( pdwEventCategories );
	CoTaskMemFree( pszDescs );

}


///////////////////////////////////////////
// Severity support
///////////////////////////////////////////
void CFilter::SetSeverity()
{
	USES_CONVERSION;

	CString strText;
	WCHAR *w=L" ";
	
	//wcscpy(w,L" ");
	m_LowSev.GetWindowText(strText);
	m_dwLowSeverity = wcstoul(T2W((LPCTSTR)strText),&w,10);

	m_HighSev.GetWindowText(strText);
	m_dwHighSeverity = wcstoul(T2W((LPCTSTR)strText),&w,10);

}

void CFilter::GetSeverity()
{
	USES_CONVERSION;
	WCHAR w[7];

	CString strText;

	_ultow(m_dwLowSeverity,w,10);
	strText=W2T(w);
	m_LowSev.SetWindowText(strText);
	
	_ultow(m_dwHighSeverity,w,10);
	strText=W2T(w);
	m_HighSev.SetWindowText(strText);
	
}

///////////////////////////////////////////
// AREA support
///////////////////////////////////////////
void CFilter::OnBremarea() 
{
	RemoveItem(m_AreaList);	
}

void CFilter::OnBaddarea() 
{
	CBrowser dlg(m_IEventServer,OPC_AREA);
	if(dlg.DoModal())
		if(!dlg.m_strArea.IsEmpty())
			BOOL bT = AddItem(0,dlg.m_strArea,m_AreaList,0,-1);
}



///////////////////////////////////////////
// SOURCE support
///////////////////////////////////////////

void CFilter::OnBaddsource() 
{
	CBrowser dlg(m_IEventServer,OPC_SOURCE);
	if(dlg.DoModal() == IDOK)
		if(!dlg.m_strSource.IsEmpty())
			BOOL bT = AddItem(0,dlg.m_strSource,m_SourceList,0,-1);
}


void CFilter::OnBremsource() 
{
	RemoveItem(m_SourceList);	
}


////////////////////////////////////////////
// other functions
////////////////////////////////////////////
HRESULT CFilter::GetFilter()
{
	HRESULT hr = S_OK;

	DWORD* pdwEventCategories;
	LPWSTR* pszAreaList;
	LPWSTR* pszSourceList;
	ADDRIGHT(hr=m_ISubMgt->GetFilter(&m_dwEventType,&m_dwNumCategories,&pdwEventCategories,
	&m_dwLowSeverity,&m_dwHighSeverity,&m_dwNumAreas,&pszAreaList,&m_dwNumSources,&pszSourceList));

	if(hr==S_OK)
	{
		
		GetEventType();	

		GetCategories(pdwEventCategories);

		GetSeverity();

		GetAreaSource(m_AreaList,m_dwNumAreas,pszAreaList);		
		GetAreaSource(m_SourceList,m_dwNumSources,pszSourceList);		
		
	}
	return hr;
}

void CFilter::GetAreaSource(CListCtrl& listCtr,DWORD dwNumber,LPWSTR* pszList)
{
	USES_CONVERSION;

	for(DWORD i = 0;i<dwNumber;i++)
	{
		BOOL bT = AddItem(0,W2T(pszList[i]),listCtr,0,-1);
		CoTaskMemFree( pszList[i] );
	}
	CoTaskMemFree(pszList);

}

void CFilter::GetCategories(DWORD* pdwEventCategories)
{
	// initialize EventList with category info

	//This is called after the event categories is already initilized m_EventList2
	//list box  it can be used to compare and find string names for the list box
		
	CString strText;
	UINT count = m_EventList2.GetCount();
	if(count == LB_ERR)
		return;

	for(DWORD dwCat = 0;dwCat<m_dwNumCategories;dwCat++)
	{
		for(UINT uiCount = 0;uiCount< count;uiCount++)
		{
			DWORD dwData = m_EventList2.GetItemData(uiCount);
			if(dwData == LB_ERR)
				break;
			else if(dwData == pdwEventCategories[dwCat])
			{
				m_EventList2.GetText(uiCount,strText);
					
				int item = m_EventList.AddString(strText);
				if(item == LB_ERR)
					break;
				item = m_EventList.SetItemData(item,pdwEventCategories[dwCat]);
				if(item == LB_ERR)
					break;
				break;
			}
		}
	
	}
	CoTaskMemFree( pdwEventCategories );  //free memory from getfilter for event categories
}

BOOL CFilter::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	HRESULT hr;
	DWORD dwFilterMask = 0;

	ADDRIGHT(hr=m_IEventServer->QueryAvailableFilters(&dwFilterMask));
	if(hr != S_OK)
		return FALSE;

	if(!(dwFilterMask & OPC_FILTER_BY_EVENT))
		m_AllCheck.EnableWindow(FALSE);
	
	if(!(dwFilterMask & OPC_FILTER_BY_CATEGORY))
	{
		m_RemEvent.EnableWindow(FALSE);
		m_AddEvent.EnableWindow(FALSE);
	}
	else
		OnInitEventList2();
	
	if(!(dwFilterMask & OPC_FILTER_BY_SEVERITY))
	{
		m_LowSev.SetReadOnly(TRUE);
		m_HighSev.SetReadOnly(TRUE);
	}

	AddColumn(m_AreaList,_T("  AREA  "),0);
	if(!(dwFilterMask & OPC_FILTER_BY_AREA))
	{
		m_RemArea.EnableWindow(FALSE);
		m_AddArea.EnableWindow(FALSE);
	}

	AddColumn(m_SourceList,_T("  SOURCE  "),0);
	if(!(dwFilterMask & OPC_FILTER_BY_SOURCE))
	{

		m_RemSource.EnableWindow(FALSE);
		m_AddSource.EnableWindow(FALSE);
	}

	ADDRIGHT(hr=GetFilter());

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CFilter::AddItem(int nSubItem ,LPCTSTR strItem,CListCtrl& itemsCtl,int nItem,int nImageIndex)
{
	LV_ITEM lvItem;
	lvItem.mask = LVIF_TEXT;
	lvItem.iItem = nItem;
	lvItem.iSubItem = nSubItem;
	lvItem.pszText = (LPTSTR) strItem;
	lvItem.cchTextMax = 255;
	lvItem.state = ~LVIS_SELECTED|~LVIS_FOCUSED;
	lvItem.stateMask = LVIS_SELECTED|LVIS_FOCUSED;
	if(nImageIndex != -1){
		lvItem.mask |= LVIF_IMAGE;
		lvItem.iImage |= LVIF_IMAGE;
	}
	if(nSubItem == 0)  //not necessary but function is more reusable with subitem == 0 check
		return itemsCtl.InsertItem(&lvItem);
	return itemsCtl.SetItem(&lvItem);
}

BOOL CFilter::AddColumn(CListCtrl& itemsCtl,LPCTSTR strItem,int nItem,int nSubItem,int nMask,int nFmt)
{
	LV_COLUMN lvc;
	lvc.mask = nMask;
	lvc.fmt = nFmt;
	lvc.pszText = (LPTSTR) strItem;
	lvc.cx = itemsCtl.GetStringWidth(lvc.pszText) + 40;
	if(nMask & LVCF_SUBITEM){
		if(nSubItem != -1)
			lvc.iSubItem = nSubItem;
		else
			lvc.iSubItem = nItem;
	}
	return itemsCtl.InsertColumn(nItem,&lvc);
}

void CFilter::RemoveItem(CListCtrl& itemsCtl)
{
	while( itemsCtl.DeleteItem( itemsCtl.GetNextItem(-1,LVNI_SELECTED)) );
}

void CFilter::OnOK() 
{
	USES_CONVERSION;
	HRESULT hr;
	

	DWORD* pdwEventCategories;
	LPWSTR* ppszAreaList;
	LPWSTR* ppszSourceList;
	wstring *wszAreaList,*wszSourceList;
	DWORD dummy;

	SetEventType();  //resolves event type
	
	// set category info

	//gets total size of list
	UINT count =	m_EventList.GetCount();
	if(count == LB_ERR)
	{
		count = 0;  //set 
		pdwEventCategories = &dummy;
	}
	else
		pdwEventCategories = new DWORD [count];

	for(UINT i = 0;i< count;i++)
	{
		pdwEventCategories[i]=m_EventList.GetItemData(i);
		if(pdwEventCategories[i]== LB_ERR)
		{
			CoTaskMemFree(pdwEventCategories);
			count=0;  //if fialed return null
			pdwEventCategories = NULL;
			break;
		}
	}
	m_dwNumCategories = count;

	SetSeverity();  //set range information

	//set area list
	m_dwNumAreas = (DWORD)m_AreaList.GetItemCount();
	if(!m_dwNumAreas)
		ppszAreaList =(LPWSTR *)&dummy;  //the stub has a problem marsheling a NULL pointer
	else
	{
		ppszAreaList = new LPWSTR [m_dwNumAreas];
		wszAreaList = new wstring [m_dwNumAreas];
	}
	for(DWORD j = 0;j<m_dwNumAreas;j++)
	{
		wszAreaList[j] = T2W((LPCTSTR)m_AreaList.GetItemText(j,0));
		ppszAreaList[j] = (LPWSTR)wszAreaList[j].data();
	}

	//set source list
	m_dwNumSources = (DWORD)m_SourceList.GetItemCount();
	if(!m_dwNumSources)
		ppszSourceList =(LPWSTR *)&dummy; //the stub has a problem marsheling a NULL pointer
	else
	{
		ppszSourceList = new LPWSTR [m_dwNumSources];
		wszSourceList = new wstring [m_dwNumSources];
	}
	for(DWORD k = 0;k<m_dwNumSources;k++)
	{
		wszSourceList[k] = T2W((LPCTSTR)m_SourceList.GetItemText(k,0));
		ppszSourceList[k] = (LPWSTR)wszSourceList[k].data();
	}
		
	
	ADDRIGHT(hr=m_ISubMgt->SetFilter(m_dwEventType,m_dwNumCategories,pdwEventCategories,
		m_dwLowSeverity,m_dwHighSeverity,m_dwNumAreas,ppszAreaList,m_dwNumSources,ppszSourceList));

	delete [] pdwEventCategories;

	if(m_dwNumAreas)
	{
		delete [] ppszAreaList;
		delete [] wszAreaList;
	}

	if(m_dwNumSources)
	{
		delete [] ppszSourceList;
		delete [] wszSourceList;
	}
		
	
	CDialog::OnOK();
}


void CFilter::OnBeginlabeleditArealist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CFilter::OnEndlabeleditArealist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = TRUE;
}

void CFilter::OnBeginlabeleditSourcelist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CFilter::OnEndlabeleditSourcelist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = TRUE;
}
