// EnableDlg.cpp : implementation file
//

#include "stdafx.h"
#include "sampleclient.h"
#include "EnableDlg.h"
#include "Browser.h"
#include "SampleClientDoc.h"
#include <afxtempl.h>
#include "ErrorHandler.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// EnableDlg dialog


EnableDlg::EnableDlg( bool bArea, CWnd* pParent /*=NULL*/)
	: CDialog(EnableDlg::IDD, pParent)
{
	m_bArea = bArea;
	//{{AFX_DATA_INIT(EnableDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void EnableDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(EnableDlg)
	DDX_Control(pDX, IDC_LIST, m_List);
	//}}AFX_DATA_MAP

	if( !m_bArea )
	{
		CString cs;
		cs.LoadString( IDS_SOURCES );
		SetDlgItemText( IDC_LISTHEADING, cs );
	}
}


BEGIN_MESSAGE_MAP(EnableDlg, CDialog)
	//{{AFX_MSG_MAP(EnableDlg)
	ON_BN_CLICKED(IDC_ADDBTN, OnAddBtn)
	ON_BN_CLICKED(IDC_REMOVEBTN, OnRemoveBtn)
	ON_BN_CLICKED(IDC_ENABLEBTN, OnEnableBtn)
	ON_BN_CLICKED(IDC_DISABLEBTN, OnDisableBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// EnableDlg message handlers

void EnableDlg::OnAddBtn() 
{
	CBrowser dlg(theDoc->m_IEventServer, m_bArea ? OPC_AREA : OPC_SOURCE);
	if(dlg.DoModal())
	{
		CString cs( m_bArea ? dlg.m_strArea : dlg.m_strSource );
		if(!cs.IsEmpty())
		{
			if( m_List.FindString( -1,  cs ) == LB_ERR )
				m_List.AddString( cs );
			CheckEnableControls();
		}
	}
}


void EnableDlg::CheckEnableControls()
{
	BOOL bEnable = m_List.GetCount();
	GetDlgItem( IDC_REMOVEBTN )->EnableWindow(  bEnable );
	GetDlgItem( IDC_ENABLEBTN )->EnableWindow(  bEnable );
	GetDlgItem( IDC_DISABLEBTN )->EnableWindow(  bEnable );
}

void EnableDlg::OnRemoveBtn() 
{

	// Get the indexes of all the selected items.
	int nCount = m_List.GetSelCount();
	CArray<int,int> aryListBoxSel;

	aryListBoxSel.SetSize(nCount);
	m_List.GetSelItems(nCount, aryListBoxSel.GetData()); 

	for( int i = nCount-1; i >= 0; i-- )
		m_List.DeleteString( aryListBoxSel[i] );

	CheckEnableControls();

}

void EnableDlg::OnEnableBtn() 
{
	DoEnable( true );	
}

void EnableDlg::OnDisableBtn() 
{
	DoEnable( false );
}


void EnableDlg::DoEnable( bool bEnable )
{
	USES_CONVERSION;

	int n = m_List.GetCount();
	LPWSTR *pszStrings = new LPWSTR[ n ];
	HRESULT* pErrors = NULL;
	CString cs;
	for( int i = 0; i < n; i++ )
	{
		m_List.GetText( i, cs );
		pszStrings[i] = T2W( cs ) ;
		
	}

	if( m_bArea )
	{
		if( bEnable )
		{
			if( theDoc->m_IEventServer2 != NULL )
			{
				ADDRIGHT( theDoc->m_IEventServer2->EnableConditionByArea2( n, pszStrings, &pErrors ) );
			}
			else
			{
				ADDRIGHT( theDoc->m_IEventServer->EnableConditionByArea( n, pszStrings ) );
			}
		}
		else // disable
		{
			if( theDoc->m_IEventServer2 != NULL )
			{
				ADDRIGHT( theDoc->m_IEventServer2->DisableConditionByArea2( n, pszStrings, &pErrors ) );
			}
			else
			{
				ADDRIGHT( theDoc->m_IEventServer->DisableConditionByArea( n, pszStrings ) );
			}
		}
	}
	else // sources
	{
		if( bEnable )
		{
			if( theDoc->m_IEventServer2 != NULL )
			{
				ADDRIGHT( theDoc->m_IEventServer2->EnableConditionBySource2( n, pszStrings, &pErrors ) );
			}
			else
			{
				ADDRIGHT( theDoc->m_IEventServer->EnableConditionBySource( n, pszStrings ) );
			}
		}
		else // disable
		{
			if( theDoc->m_IEventServer2 != NULL )
			{
				ADDRIGHT( theDoc->m_IEventServer2->DisableConditionBySource2( n, pszStrings, &pErrors ) );
			}
			else
			{
				ADDRIGHT( theDoc->m_IEventServer->DisableConditionBySource( n, pszStrings ) );
			}
		}
	}

	// TODO look for errors in pErrors

	if( pErrors )
	{
		CString sError;
		for( int i = 0; i < n; i++ )
		{
			if( pErrors[i] != S_OK )
			{
				if( sError.IsEmpty() )
					sError = _T("The following items returned errors:\r\n\r\nERROR CODE  SOURCE or AREA\r\n");
				TCHAR buf[80];
				wsprintf( buf, _T("0x%X       "), pErrors[i] );
				sError += buf;
				m_List.GetText( i, cs );
				sError += cs;
				sError += _T("\r\n");
			}
		}
		if( !sError.IsEmpty() )
			AfxMessageBox( sError );
	}



	CoTaskMemFree( pErrors );
	delete [] pszStrings;
}
