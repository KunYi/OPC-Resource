// TagListView.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: TagListView.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 18 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/TagListView.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: TagListView.cpp $
 * 
 * *****************  Version 18  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 17  *****************
 * User: Jiml         Date: 8/10/98    Time: 5:20p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Added support for BSTR arrays in attributes
 * 
 * *****************  Version 16  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          

// TagListView.cpp : implementation file
//

#include "stdafx.h"
#include "opcae_er.h"
#include "GlobalVar.h"
#include "ErrorHandler.h"
#include "SampleClientDoc.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define nATTR_COLS 20

/////////////////////////////////////////////////////////////////////////////
// CTagListView

IMPLEMENT_DYNCREATE(CTagListView, CListView)

CTagListView::CTagListView()
{
}

CTagListView::~CTagListView()
{
}




BEGIN_MESSAGE_MAP(CTagListView, CListView)
	//{{AFX_MSG_MAP(CTagListView)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTagListView drawing

void CTagListView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

void CTagListView::Clear()
{
	CListCtrl& m_itemsCtl = GetListCtrl();

	CleanUp();
	m_itemsCtl.DeleteAllItems();

}


void CTagListView::CleanUp()
{
	EventStruct* pEventStruct;

	CListCtrl& m_itemsCtl = GetListCtrl();
	DWORD dwlParam = 0;

	DWORD dwcount = m_itemsCtl.GetItemCount();
	for(DWORD i = 0;i<dwcount;i++)
	{
		dwlParam = m_itemsCtl.GetItemData(i);
		if(dwlParam)
		{
			pEventStruct=(EventStruct *&)dwlParam;
			delete pEventStruct;
			
		}
	}
}

void CTagListView::OnDestroy() 
{
	Clear();

	CListView::OnDestroy();
}

BOOL CTagListView::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	cs.style = WS_CHILD | WS_VISIBLE | WS_BORDER | LVS_REPORT; // | TVS_DISABLEDRAGDROP;
	
	return CListView::PreCreateWindow(cs);
}

void CTagListView::SetHeader()
{
	USES_CONVERSION;

	//CListCtrl& m_itemsCtl = GetListCtrl();

	//m_itemsCtl.InsertColumn(0, W2T(wszHeader.data()) , LVCFMT_LEFT, 300, -1);
	AddColumn(_T("Mask"),0);
	AddColumn(_T("NewState "),1);
	AddColumn(_T("  Source  "),2);
	AddColumn(_T("Event Time "),3);
	AddColumn(_T("Message"),4);
	AddColumn(_T("Event Type "),5);
	AddColumn(_T("E Cat"),6);
	AddColumn(_T("Severity"),7);
	AddColumn(_T("Condition Name"),8);
	AddColumn(_T("Sub Name"),9);
	AddColumn(_T("Quality"),10);
	AddColumn(_T("AckReq"),11);
	AddColumn(_T("Active Time"),12);
	AddColumn(_T("Cookie"),13);
	AddColumn(_T("Actor ID"),14);
	AddColumn(_T("#Attrs"),15);

	for( int i = 0; i < nATTR_COLS; i++ )
	{
		CString s( _T("Attr #") );
		TCHAR buf[20];
		s += _itot( i, buf, 10 );
		AddColumn(s,16+i);
	}

	UpdateWindow();
}

BOOL CTagListView::AddColumn(LPCTSTR strItem,int nItem,int nSubItem,int nMask,int nFmt)
{
	CListCtrl& m_itemsCtl = GetListCtrl();

	LV_COLUMN lvc;
	lvc.mask = nMask;
	lvc.fmt = nFmt;
	lvc.pszText = (LPTSTR) strItem;
	lvc.cx = m_itemsCtl.GetStringWidth(lvc.pszText) + 6;
	if(nMask & LVCF_SUBITEM){
		if(nSubItem != -1)
			lvc.iSubItem = nSubItem;
		else
			lvc.iSubItem = nItem;
	}
	return m_itemsCtl.InsertColumn(nItem,&lvc);
}

void CTagListView::AddItem(/*wstring& wszTextString,*/const EventStruct& Event)
{
	USES_CONVERSION;


	EventStruct* pEventStruct;	
	CListCtrl& m_itemsCtl = GetListCtrl();
	wstring wszText;
	TCHAR t[255];

	//initialize stored event struct and store it in event class
	pEventStruct = new EventStruct;
	*pEventStruct = Event;

	//add wchangemask to list control item
	wsprintf(t,"0x%x",pEventStruct->m_wChangeMask);

	//first item in list control. contians pointer to stored structure 
	LV_ITEM lv_item;
	lv_item.mask = LVIF_TEXT|LVIF_PARAM;
	lv_item.iSubItem = 0;
	lv_item.iItem = 0;
	lv_item.state = ~LVIS_SELECTED|~LVIS_FOCUSED;
	lv_item.stateMask = LVIS_SELECTED|LVIS_FOCUSED;
	lv_item.pszText = t;
	//pointer to stored structure
	(void *&)lv_item.lParam = (void *)pEventStruct;

	int item = m_itemsCtl.InsertItem(&lv_item); //need a method to protect this during shutdown

	BOOL bT;

	//add new state to subitem	
	_tcscpy(t,_T(" "));
	if(pEventStruct->m_wNewState&OPC_CONDITION_ACTIVE)
		_tcscat(t,_T("ACT "));
	if(pEventStruct->m_wNewState&OPC_CONDITION_ENABLED)
		_tcscat(t,_T("ENA "));
	if(pEventStruct->m_wNewState&OPC_CONDITION_ACKED)
		_tcscat(t,_T("ACK "));
	bT=AddSubItem(1,t);

	//add source to next subitem
	wszText=pEventStruct->m_wszSource;
	if(wszText.length() > 255)
		wszText=wszText.erase(255,wszText.length()-255);
	bT=AddSubItem(2,W2T(wszText.data()));

	//add time to next subitem
	COleDateTime odt((FILETIME)pEventStruct->m_ftTime);  
	bT=AddSubItem(3,(LPCTSTR)odt.Format(LOCALE_NOUSEROVERRIDE,LANG_USER_DEFAULT));

	//add message to next subitem
	wszText=pEventStruct->m_wszMessage;
	if(wszText.length() > 255)
		wszText=wszText.erase(255,wszText.length()-255);
	bT=AddSubItem(4,W2T(wszText.data()));

	//add event type to next subitem
	switch(pEventStruct->m_dwEventType)
	{
	case OPC_SIMPLE_EVENT:
		_tcscpy(t,_T("SIMP"));
		break;
	case OPC_CONDITION_EVENT:
		_tcscpy(t,_T("COND"));
		break;
	case OPC_TRACKING_EVENT:
		_tcscpy(t,_T("TRAC"));
		break;
	default:
		_tcscpy(t,_T("Invalid Event"));
	}
	bT=AddSubItem(5,t);

	//add event category to next subitem
	wsprintf(t,"%u",pEventStruct->m_dwEventCategory);  
	bT=AddSubItem(6,t);

	//add severity to next subitem
	wsprintf(t,"%u",pEventStruct->m_dwSeverity);  
	bT=AddSubItem(7,t);

	//add condition name to next subitem
	wszText=pEventStruct->m_wszConditionName;
	if(wszText.length() > 255)
		wszText=wszText.erase(255,wszText.length()-255);
	bT=AddSubItem(8,W2T(wszText.data()));

	//add sub condition name to next subitem
	wszText=pEventStruct->m_wszSubConditionName;
	if(wszText.length() > 255)
		wszText=wszText.erase(255,wszText.length()-255);
	bT=AddSubItem(9,W2T(wszText.data()));

	//add quality to next subitem
	wsprintf(t,"0x%x",pEventStruct->m_wQuality);
	bT=AddSubItem(10,t);

	//add ack required to next subitem
	wsprintf(t,"%d",pEventStruct->m_bAckRequired);
	bT=AddSubItem(11,t);

	//add active time to next subitem
	odt = (FILETIME)pEventStruct->m_ftActiveTime;  
	bT=AddSubItem(12,(LPCTSTR)odt.Format(LOCALE_NOUSEROVERRIDE,LANG_USER_DEFAULT));
	
	//add cookie to next subitem
	wsprintf(t,"%u",pEventStruct->m_dwCookie);  
	bT=AddSubItem(13,t);
	
	
	//add actor ID to last subitem
	wszText=pEventStruct->m_wszActorID;
	if(wszText.length() > 255)
		wszText=wszText.erase(255,wszText.length()-255);
	bT=AddSubItem(14,W2T(wszText.data()));

	//add numeventattrs to next subitem
	wsprintf(t,"%u",pEventStruct->m_dwNumEventAttrs);  
	bT=AddSubItem(15,t);

	//eventattributes

	int count = min( pEventStruct->m_dwNumEventAttrs, nATTR_COLS );
	for( int i = 0; i < count; i++ )
	{
		if( SUCCEEDED(pEventStruct->m_EventAttributes[i].ChangeType( VT_BSTR )) )
			bT=AddSubItem(16+i, W2T(pEventStruct->m_EventAttributes[i].bstrVal) );
		else if( pEventStruct->m_EventAttributes[i].vt == (VT_ARRAY | VT_BSTR) )
		{
			COleSafeArray s( pEventStruct->m_EventAttributes[i] );
			if( s.GetDim() == 1 )
			{
				long lBound;
				long uBound;
				s.GetLBound( 1, &lBound );
				s.GetUBound( 1, &uBound );
				CString cs;
				for( long j = lBound; j <= uBound; j++ ) 
				{
					BSTR b;
					s.GetElement( &j, &b );
					cs += W2T(b);
					cs += '\t';
				}
				bT=AddSubItem(16+i, cs );
			}
		}
	}


	bT = m_itemsCtl.SetTextColor(RGB(255,0,0));

	
}

BOOL CTagListView::AddSubItem(int nSubItem,LPCTSTR strItem,int nItem,int nImageIndex)
{
	CListCtrl& m_itemsCtl = GetListCtrl();

	LV_ITEM lvItem;
	lvItem.mask = LVIF_TEXT;
	lvItem.iItem = nItem;
	lvItem.iSubItem = nSubItem;
	lvItem.pszText = (LPTSTR) strItem;
	lvItem.cchTextMax = 255;
	lvItem.state = ~LVIS_SELECTED|~LVIS_FOCUSED;
	lvItem.stateMask = LVIS_SELECTED|LVIS_FOCUSED;
	if(nImageIndex != -1){
		lvItem.mask |= LVIF_IMAGE;
		lvItem.iImage |= LVIF_IMAGE;
	}
	if(nSubItem == 0)  //not necessary but function is more reusable with subitem == 0 check
		return m_itemsCtl.InsertItem(&lvItem);
	return m_itemsCtl.SetItem(&lvItem);
}



/////////////////////////////////////////////////////////////////////////////
// CTagListView diagnostics

#ifdef _DEBUG
void CTagListView::AssertValid() const
{
	CListView::AssertValid();
}

void CTagListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTagListView message handlers

void CTagListView::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	EventStruct* pEventStruct;
	NMLISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	DWORD dwlParam = 0;

	CListCtrl& m_itemsCtl = GetListCtrl();

	*pResult = 0;

	if(pNMListView->iItem == -1)
		return;

	dwlParam = m_itemsCtl.GetItemData(pNMListView->iItem);
	pEventStruct=(EventStruct *&)dwlParam;
	if(pEventStruct==NULL)  //wrong list control
		return;

	if(!pEventStruct->m_bAckRequired)
	{
	   MessageBox(_T("No Ack Required"), "Alarm Ack", MB_APPLMODAL | MB_ICONHAND);
	   return;
	}

	CSampleClientDoc* pDoc = (CSampleClientDoc *)GetDocument();
	if(pDoc == NULL)
	{
		MessageBox(_T("No Document Found"), "Alarm Ack", MB_APPLMODAL | MB_ICONHAND);
		return;
	}


	DWORD dwCount;
	wstring wszAcknowledgerID(L"SampleCient");
	wstring wszComment(L"Acknowledged");
	LPWSTR* pszSource;
	LPWSTR* pszConditionName;
	FILETIME* pftActiveTime;
	DWORD* pdwCookie;
	HRESULT* pErrors;

	dwCount =1;

	pszSource = new LPWSTR [dwCount]; 
	pszConditionName = new LPWSTR [dwCount]; 
	pftActiveTime = new FILETIME [dwCount]; 
	pdwCookie = new DWORD [dwCount]; 
	
	for(DWORD i=0;i<dwCount;i++)
	{
		pszSource[i] = (LPWSTR)pEventStruct->m_wszSource.data();
		pszConditionName[i] = (LPWSTR)pEventStruct->m_wszConditionName.data();
		pftActiveTime[i] = (FILETIME)pEventStruct->m_ftActiveTime;
		pdwCookie[i] = pEventStruct->m_dwCookie;
		TRACE( "%ls  %ls\n", pszSource[i], 
								pszConditionName[i] );
	}


	//Acknowledging a single condition
	HRESULT hr;
	ADDRIGHT(hr = pDoc->m_IEventServer->AckCondition(dwCount,(LPWSTR)wszAcknowledgerID.data(),(LPWSTR)wszComment.data(),pszSource,
		pszConditionName,pftActiveTime,pdwCookie,&pErrors));
	if(hr == S_FALSE)
		for(DWORD i = 0;i<dwCount;i++)
		{
			if(pErrors[i]==OPC_S_ALREADYACKED)
				MessageBox(_T("Alarm already acked"), "Alarm Ack", MB_APPLMODAL | MB_ICONHAND);
			else if(pErrors[i]==OPC_E_INVALIDTIME)
				MessageBox(_T("Time does not match lasted active time"), "Alarm Ack", MB_APPLMODAL | MB_ICONHAND);
			else if(pErrors[i]==E_INVALIDARG)
				MessageBox(_T("Bad Argument Passed to Server"), "Alarm Ack", MB_APPLMODAL | MB_ICONHAND);
			else 
			{
				CString strText;
				strText.Format("Unknown Error hr = %x",pErrors[i]);
				MessageBox(strText, "Alarm Ack", MB_APPLMODAL | MB_ICONHAND);
			}
		}

	delete [] pszSource;
	delete [] pszConditionName;
	delete [] pftActiveTime;
	delete [] pdwCookie;
	CoTaskMemFree(pErrors);
	pErrors=NULL;
	
}

void CTagListView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	Clear();

}
