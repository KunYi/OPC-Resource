// AttributeMap.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: AttributeMap.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 5 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/AttributeMap.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: AttributeMap.h $
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 4  *****************
 * User: Jiml         Date: 5/19/98    Time: 5:27p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * No longer crashes the compiller when compiled under 95!
 * 
 * *****************  Version 3  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#ifndef __ATTRIBUTEMAP_H
#define __ATTRIBUTEMAP_H

#pragma warning( disable : 4786 )
#include <map>
#include <string> 
using namespace std;

using namespace std;

class OPCAttrib
{
public:
	wstring wszAttrDescs;
	VARTYPE vtAttrTypes;
};

// map Attribute ID to Attribute string and var type
class AttributeMap : public  map<DWORD, OPCAttrib, less<DWORD> >
{
};

class EventMap : public map<DWORD, AttributeMap, less<DWORD> >
{
};

#endif