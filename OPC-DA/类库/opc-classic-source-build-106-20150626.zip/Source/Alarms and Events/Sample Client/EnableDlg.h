#if !defined(AFX_ENABLEDLG_H__8B9788A3_E3C7_44FB_9EB2_24E52AC15CE3__INCLUDED_)
#define AFX_ENABLEDLG_H__8B9788A3_E3C7_44FB_9EB2_24E52AC15CE3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EnableDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// EnableDlg dialog

class EnableDlg : public CDialog
{
private:
	bool m_bArea;
	void CheckEnableControls();
	void DoEnable( bool bEnable );
// Construction
public:
	EnableDlg(bool bArea, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(EnableDlg)
	enum { IDD = IDD_ENABLEDLG_DIALOG };
	CListBox	m_List;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EnableDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(EnableDlg)
	afx_msg void OnAddBtn();
	afx_msg void OnRemoveBtn();
	afx_msg void OnEnableBtn();
	afx_msg void OnDisableBtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ENABLEDLG_H__8B9788A3_E3C7_44FB_9EB2_24E52AC15CE3__INCLUDED_)
