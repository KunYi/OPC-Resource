// ServerStatus.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: ServerStatus.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 3 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/ServerStatus.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: ServerStatus.cpp $
 * 
 * *****************  Version 3  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 2  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// ServerStatus.cpp : implementation file
//

#include "stdafx.h"
#include "sampleclient.h"
#include "ServerStatus.h"
//included for error handling
#include "ErrorHandler.h"
#include "GlobalVar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerStatus dialog


CServerStatus::CServerStatus(IOPCEventServerPtr& newEventServerPtr,CWnd* pParent /*=NULL*/)
	: CDialog(CServerStatus::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServerStatus)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
   m_IEventServer = newEventServerPtr;  // Get an IOPCCommonPtr interface

}


void CServerStatus::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerStatus)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CServerStatus, CDialog)
	//{{AFX_MSG_MAP(CServerStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerStatus message handlers

BOOL CServerStatus::OnInitDialog() 
{
	CDialog::OnInitDialog();

	HRESULT hr;

	OPCEVENTSERVERSTATUS* pEventServerStatus;

	ADDRIGHT(hr = m_IEventServer->GetStatus(&pEventServerStatus));
	if(hr==S_OK)
	{
		CString str;
		COleDateTime odt(pEventServerStatus->ftStartTime);

		str=odt.Format(LOCALE_NOUSEROVERRIDE,LANG_USER_DEFAULT);
		SetDlgItemText(IDC_STARTTIME,(LPCTSTR)str);
		
		odt=pEventServerStatus->ftCurrentTime;
		str=odt.Format(LOCALE_NOUSEROVERRIDE,LANG_USER_DEFAULT);
		SetDlgItemText(IDC_CURRTIME,(LPCTSTR)str);

		odt=pEventServerStatus->ftLastUpdateTime;
		str=odt.Format(LOCALE_NOUSEROVERRIDE,LANG_USER_DEFAULT);
		SetDlgItemText(IDC_LASTTIME,(LPCTSTR)str);

		switch(pEventServerStatus->dwServerState)
		{
		case OPCAE_STATUS_RUNNING:
			str=_T("OPC_STATUS_RUNNING");
			break;
		case OPCAE_STATUS_FAILED:
			str=_T("OPC_STATUS_FAILED");
			break;
		case OPCAE_STATUS_NOCONFIG:
			str=_T("OPC_STATUS_NOCONFIG");
			break;
		case OPCAE_STATUS_SUSPENDED:
			str=_T("OPC_STATUS_SUSPENDED");
			break;
		case OPCAE_STATUS_TEST:
			str=_T("OPC_STATUS_TEST");
			break;
		default:
			str=_T("INVALID SERVER STATE");
		}
		SetDlgItemText(IDC_SERVSTATE,(LPCTSTR)str);

		TCHAR t[256];

		wsprintf(t,"%d",pEventServerStatus->wMajorVersion);
		SetDlgItemText(IDC_MAJORVER,t);

		wsprintf(t,"%d",pEventServerStatus->wMinorVersion);
		SetDlgItemText(IDC_MINORVER,t);

		wsprintf(t,"%d",pEventServerStatus->wBuildNumber);
		SetDlgItemText(IDC_BUILDNUM,t);

		wsprintf(t,"%ls",pEventServerStatus->szVendorInfo);
		SetDlgItemText(IDC_VENDORINFO,t);
	}

	//free vendor info string
	CoTaskMemFree(pEventServerStatus->szVendorInfo);
	//free structure
	CoTaskMemFree(pEventServerStatus);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


