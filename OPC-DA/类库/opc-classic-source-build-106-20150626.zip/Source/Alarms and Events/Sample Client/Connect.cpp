// Connect.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Connect.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 6 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Connect.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Connect.cpp $
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 5/19/98    Time: 5:42p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 4  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#include "stdafx.h"
#include "resource.h"
#include "Connect.h"

//included for error handling
#include "ErrorHandler.h"
#include "GlobalVar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// CConnect dialog


CConnect::CConnect(CWnd* pParent /*=NULL*/)
	: CDialog(CConnect::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnect)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CConnect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnect)
	DDX_Control(pDX, IDC_LIST1, m_AlarmServerList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnect, CDialog)
	//{{AFX_MSG_MAP(CConnect)
	ON_LBN_DBLCLK(IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnect message handlers

void CConnect::OnDblclkList1() 
{
	OnOK();
}

void CConnect::OnOK() 
{
	LaunchServer();
	CDialog::OnOK();
}

void CConnect::LaunchServer()
{
	CWaitCursor	cWait;		//show wait cursor.
	HRESULT hr;
	int item = m_AlarmServerList.GetCurSel();
	if(item == LB_ERR)
		return;
	CLSID* pData=NULL;
	pData = (CLSID *)m_AlarmServerList.GetItemDataPtr(item);
	ADDRIGHT(hr = m_IEventServer.CreateInstance(*pData));

	if(hr==S_OK)
	{
		UINT count = m_AlarmServerList.GetCount();
		if(item == LB_ERR)
			return;
		for(UINT i=0;i<count;i++)
		{
			pData = (CLSID *)m_AlarmServerList.GetItemDataPtr(i);
			delete pData;
		}
	}
}


BOOL CConnect::OnInitDialog() 
{	
	USES_CONVERSION;
	CDialog::OnInitDialog();
	
	ICatInformation* pcr = NULL;
	HRESULT hr=S_OK;

	ADDRIGHT(hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, NULL, CLSCTX_INPROC_SERVER, IID_ICatInformation, (void**)&pcr));

	IEnumCLSID* pEnumCLSID;

	CLSID catid =  __uuidof(OPCEventServerCATID);
	pcr->EnumClassesOfCategories(1, &catid, 1, &catid, &pEnumCLSID);

	//get 10 at a time for efficiency
	unsigned long c;
	CLSID clsids[10];

	CString strText;
	WCHAR* lpszProgID = NULL;
	int item;

	while(SUCCEEDED(hr=pEnumCLSID->Next(10,clsids, &c)) && c)
	{
		for(unsigned long i =0;i<c;i++)
		{
			clsids[i];
			ADDRIGHT(hr=ProgIDFromCLSID(clsids[i],&lpszProgID));
			strText=W2T(lpszProgID);
			CoTaskMemFree( lpszProgID );
			item = m_AlarmServerList.AddString(strText);
			if(item==LB_ERR)
				return FALSE;
			CLSID* pData;
			pData = new CLSID;
			*pData = clsids[i];
			item = m_AlarmServerList.SetItemDataPtr(item,pData);
			if(item==LB_ERR)
				return FALSE;
		}
	}


	pcr->Release();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
