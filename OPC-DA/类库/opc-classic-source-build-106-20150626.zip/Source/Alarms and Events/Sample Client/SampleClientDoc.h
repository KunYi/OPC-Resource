// SampleClientDoc.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: SampleClientDoc.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 17 $
//       $Date: 8/02/02 4:47p $
//    $Archive: /OPC/AlarmEvents/SampleClient/SampleClientDoc.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: SampleClientDoc.h $
 * 
 * *****************  Version 17  *****************
 * User: Jiml         Date: 8/02/02    Time: 4:47p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 16  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 15  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// SampleClientDoc.h : interface of the CSampleClientDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SAMPLECLIENTDOC_H__81824B1F_821A_11D1_84BB_00608CB8A7E9__INCLUDED_)
#define AFX_SAMPLECLIENTDOC_H__81824B1F_821A_11D1_84BB_00608CB8A7E9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "OPCEventSink.h"
#include "OPCShutdownReq.h"

class CSampleClientDoc : public CDocument
{
protected: // create from serialization only
	CSampleClientDoc();
	DECLARE_DYNCREATE(CSampleClientDoc)
	DWORD m_dwCookie,m_dwShutdownCookie;

// Attributes
public:
	IOPCEventServerPtr			m_IEventServer;
	IOPCEventServer2Ptr			m_IEventServer2;
	IOPCEventSubscriptionMgtPtr m_ISub;
	IOPCCommonPtr				m_ICommon;
	CComObject<COPCEventSink>   *m_pSink;
	CComObject<COPCShutdownRequest>  *m_pShutdown;


	BOOL m_bConnected,m_bSubscription;

// Operations
public:
	void SetMenuEventState(CCmdUI* pCmdUI,BOOL bConnected=FALSE); 
	void SetMenuSubscrState(CCmdUI* pCmdUI,BOOL bSubscription=FALSE); 
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSampleClientDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSampleClientDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSampleClientDoc)
	afx_msg void OnOpcConnect();
	afx_msg void OnUpdateOpcConnect(CCmdUI* pCmdUI);
	afx_msg void OnOpcDisconnect();
	afx_msg void OnUpdateOpcDisconnect(CCmdUI* pCmdUI);
	afx_msg void OnOpcGetstatus();
	afx_msg void OnUpdateOpcGetstatus(CCmdUI* pCmdUI);
	afx_msg void OnViewClearAll();
	afx_msg void OnViewClearLeft();
	afx_msg void OnViewClearRight();
	afx_msg void OnOpcLanguage();
	afx_msg void OnUpdateOpcLanguage(CCmdUI* pCmdUI);
	afx_msg void OnOpcBrowser();
	afx_msg void OnUpdateOpcBrowser(CCmdUI* pCmdUI);
	afx_msg void OnOpcFilter();
	afx_msg void OnUpdateOpcFilter(CCmdUI* pCmdUI);
	afx_msg void OnOpcAttributes();
	afx_msg void OnUpdateOpcAttributes(CCmdUI* pCmdUI);
	afx_msg void OnOpcEventsub();
	afx_msg void OnUpdateOpcEventsub(CCmdUI* pCmdUI);
	afx_msg void OnOpcRefresh();
	afx_msg void OnUpdateOpcRefresh(CCmdUI* pCmdUI);
	afx_msg void OnOpcCancelrefresh();
	afx_msg void OnUpdateOpcCancelrefresh(CCmdUI* pCmdUI);
	afx_msg void OnOpcTest();
	afx_msg void OnUpdateEnableByArea(CCmdUI* pCmdUI);
	afx_msg void OnEnableByArea();
	afx_msg void OnEnableSource();
	afx_msg void OnUpdateEnableSource(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CSampleClientDoc *theDoc;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAMPLECLIENTDOC_H__81824B1F_821A_11D1_84BB_00608CB8A7E9__INCLUDED_)
