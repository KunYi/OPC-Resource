// DebugListView.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: DebugListView.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 7 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/DebugListView.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: DebugListView.cpp $
 * 
 * *****************  Version 7  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 5/19/98    Time: 5:27p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * No longer crashes the compiller when compiled under 95!
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
//*************************************************************************
//
//   Copyright (c) 1997 ICONICS INC. (copyrighted as an unpublished work)
//                 CONFIDENTIAL: Contains TRADE SECRET information
//
//-------------------------------------------------------------------------
//
//    Filename: DebugListView.cpp
//
//      System: Olexpress
//
//     Classes:	CDebugListView
//              
//
// Description:
//
//-------------------------------------------------------------------------
//      History of Major Revisions
//
//      Vers.   Rev.    Date        Who         Comments
//      -----   -----   --------    -------     ---------------------------
//
//*************************************************************************
//
// DebugListView.cpp : implementation file
//

#include "stdafx.h"
#include "DebugListView.h"
#include "resource.h"
#include <string> 
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDebugListView

IMPLEMENT_DYNCREATE(CDebugListView, CListView)

CDebugListView::CDebugListView()
{
}

CDebugListView::~CDebugListView()
{
}


BEGIN_MESSAGE_MAP(CDebugListView, CListView)
	//{{AFX_MSG_MAP(CDebugListView)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDebugListView drawing

void CDebugListView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

void CDebugListView::Clear()
{
	CListCtrl& m_itemsCtl = GetListCtrl();

	m_itemsCtl.DeleteAllItems();
}

void CDebugListView::OnDestroy() 
{
	Clear();

	CListView::OnDestroy();
}

BOOL CDebugListView::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	cs.style = WS_CHILD | WS_VISIBLE | WS_BORDER | LVS_REPORT; // | TVS_DISABLEDRAGDROP;
	
	return CListView::PreCreateWindow(cs);
}

void CDebugListView::SetHeader()
{
	CListCtrl& m_itemsCtl = GetListCtrl();

	m_itemsCtl.InsertColumn(0, _T("OPC Interfaces and Methods") , LVCFMT_LEFT, 300, -1);
	UpdateWindow();
}

void CDebugListView::AddText(LPCWSTR wszText)
{
	USES_CONVERSION;
	
	wstring wszTextString = wszText;
	CListCtrl& m_itemsCtl = GetListCtrl();

	if(wszTextString.length() > 255)
		wszTextString=wszTextString.erase(255,wszTextString.length()-255);

	LV_ITEM lv_item;

	lv_item.mask = LVIF_TEXT;
	lv_item.iSubItem = 0;
	lv_item.iItem = 0;
	lv_item.state = ~LVIS_SELECTED|~LVIS_FOCUSED;
	lv_item.stateMask = LVIS_SELECTED|LVIS_FOCUSED;
	lv_item.pszText = W2T(wszTextString.data());

	int item = m_itemsCtl.InsertItem(&lv_item);

}

/////////////////////////////////////////////////////////////////////////////
// CDebugListView diagnostics

#ifdef _DEBUG
void CDebugListView::AssertValid() const
{
	CListView::AssertValid();
}

void CDebugListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDebugListView message handlers
void CDebugListView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	Clear();
}

