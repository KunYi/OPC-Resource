//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SampleClient.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_ENABLEDLG_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDR_SAMPLETYPE                  129
#define IDS_SOURCES                     129
#define IDD_OPCCOMMON                   131
#define IDD_SERVERSTAT                  133
#define IDD_BROWSER                     134
#define IDB_BITMAP1                     135
#define IDB_BITMAP2                     136
#define IDB_BITMAP3                     138
#define IDD_FILTER                      139
#define IDD_ATTRIBUTE                   140
#define IDD_EVENTSUB                    141
#define IDD_CONNECT                     142
#define IDC_CLIENT                      1005
#define IDC_IDCOMBO                     1006
#define IDC_CURRENT_ID                  1007
#define IDC_STARTTIME                   1008
#define IDC_CURRTIME                    1009
#define IDC_LASTTIME                    1010
#define IDC_SERVSTATE                   1011
#define IDC_MAJORVER                    1012
#define IDC_MINORVER                    1013
#define IDC_BUILDNUM                    1014
#define IDC_VENDORINFO                  1015
#define IDC_BROWSETREE                  1016
#define IDC_AREAEDIT                    1017
#define IDC_SOURCEEDIT                  1018
#define IDC_FILTEREDIT                  1021
#define IDC_AREACHECK                   1022
#define IDC_SOURCECHECK                 1023
#define IDC_LOWSEVEDIT                  1024
#define IDC_HIGHSEVEDIT                 1025
#define IDC_CONDCHECK                   1033
#define IDC_SIMPCHECK                   1034
#define IDC_ALLCHECK                    1035
#define IDC_TRACKCHECK                  1036
#define IDC_BREMEVENT                   1041
#define IDC_BREMAREA                    1042
#define IDC_BREMATTRIB                  1042
#define IDC_BREMSOURCE                  1045
#define IDC_BADDAREA                    1046
#define IDC_BADDSOURCE                  1047
#define IDC_AREALIST                    1048
#define IDC_SOURCELIST                  1049
#define IDC_EVENTLIST                   1050
#define IDC_BADDEVENT                   1051
#define IDC_EVENTLIST2                  1052
#define IDC_ATTRIBLIST                  1053
#define IDC_BADDATTRIB                  1054
#define IDC_ATTRIBLIST2                 1055
#define IDC_DWCAT                       1063
#define IDC_ACTIVECHECK                 1064
#define IDC_BUFFERTIMEEDIT              1065
#define IDC_MAXSIZEEDIT                 1066
#define IDC_CLIENTEDIT                  1067
#define IDC_EVENTCOMBO                  1068
#define IDC_NULLCHECK                   1069
#define IDC_APPLYBUTTON                 1070
#define IDC_LIST1                       1071
#define IDC_LIST                        1072
#define IDC_LISTHEADING                 1073
#define IDC_ADDBTN                      1074
#define IDC_REMOVEBTN                   1075
#define IDC_ENABLEBTN                   1076
#define IDC_DISABLEBTN                  1077
#define ID_OPC_CONNECT                  32775
#define ID_OPC_DISCONNECT               32776
#define ID_OPC_GETSTATUS                32777
#define ID_VIEW_CLEAR_ALL               32778
#define ID_VIEW_CLEAR_LEFT              32779
#define ID_VIEW_CLEAR_RIGHT             32780
#define ID_OPC_LANGUAGE                 32782
#define ID_OPC_BROWSER                  32783
#define ID_OPC_FILTER                   32784
#define ID_OPC_ATTRIBUTES               32785
#define ID_OPC_EVENTSUB                 32786
#define ID_OPC_REFRESH                  32787
#define ID_OPC_CANCELREFRESH            32788
#define ID_OPC_TEST                     32789
#define IDM_ENABLEBYARE                 32790
#define IDM_ENABLEBYAREA                32791
#define IDM_ENABLESOURCE                32792

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1078
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
