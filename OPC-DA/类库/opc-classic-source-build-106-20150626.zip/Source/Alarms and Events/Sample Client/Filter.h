// Filter.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Filter.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 10 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Filter.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Filter.h $
 * 
 * *****************  Version 10  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 9  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#if !defined(AFX_FILTER_H__9BB7A265_C3FC_11D1_9E05_00608CB8A6B0__INCLUDED_)
#define AFX_FILTER_H__9BB7A265_C3FC_11D1_9E05_00608CB8A6B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Filter.h : header file
//
#pragma warning( disable : 4786 )


/////////////////////////////////////////////////////////////////////////////
// CFilter dialog

class CFilter : public CDialog
{
// Construction
public:
	CFilter(IOPCEventServerPtr& newIEventServer,IOPCEventSubscriptionMgtPtr& m_ISubMgt,CWnd* pParent = NULL);   // constructor
	void OnThreeCheck();
	void OnInitEventList2();
	BOOL AddItem(int nSubItem ,LPCTSTR strItem,CListCtrl& itemsCtl,int nItem,int nImageIndex);
	BOOL AddColumn(CListCtrl& itemsCtl,LPCTSTR strItem,int nItem,int nSubItem=-1,
		int nMask=LVCF_WIDTH|LVCF_TEXT|LVCF_FMT|LVCF_ORDER,int nFmt=LVCFMT_CENTER);
	void RemoveItem(CListCtrl& itemsCtl);
	void SetEventType();
	void GetEventType();
	void GetSeverity();
	void SetSeverity();
	void GetCategories(DWORD* pdwEventCategories);
	void GetAreaSource(CListCtrl& listCtr,DWORD dwNumber,LPWSTR* pszList);
	HRESULT GetFilter();




	DWORD m_dwEventType;
	DWORD m_dwNumCategories;
	DWORD m_dwLowSeverity;
	DWORD m_dwHighSeverity;
	DWORD m_dwNumAreas;
	DWORD m_dwNumSources;




// Dialog Data
	//{{AFX_DATA(CFilter)
	enum { IDD = IDD_FILTER };
	CListBox	m_EventList2;
	CButton	m_TracCheck;
	CButton	m_RemSource;
	CButton	m_RemEvent;
	CButton	m_RemArea;
	CButton	m_AddSource;
	CButton	m_AddEvent;
	CButton	m_AddArea;
	CButton	m_SimpCheck;
	CListCtrl	m_SourceList;
	CEdit	m_LowSev;
	CEdit	m_HighSev;
	CListBox	m_EventList;
	CButton	m_CondCheck;
	CListCtrl	m_AreaList;
	CButton	m_AllCheck;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilter)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	IOPCEventServerPtr m_IEventServer;
	IOPCEventSubscriptionMgtPtr m_ISubMgt;

	// Generated message map functions
	//{{AFX_MSG(CFilter)
	afx_msg void OnAllcheck();
	afx_msg void OnCondcheck();
	afx_msg void OnSimpcheck();
	afx_msg void OnTrackcheck();
	afx_msg void OnBaddarea();
	afx_msg void OnBaddevent();
	afx_msg void OnBaddsource();
	afx_msg void OnBremarea();
	afx_msg void OnBremevent();
	afx_msg void OnBremsource();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBeginlabeleditArealist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeleditArealist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginlabeleditSourcelist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeleditSourcelist(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTER_H__9BB7A265_C3FC_11D1_9E05_00608CB8A6B0__INCLUDED_)
