// TagListView.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: TagListView.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 9 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/TagListView.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: TagListView.h $
 * 
 * *****************  Version 9  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 8  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          

#if !defined(AFX_TAGLISTVIEW_H__04D7BE04_FF4C_11D0_984F_00A024A3D341__INCLUDED_)
#define AFX_TAGLISTVIEW_H__04D7BE04_FF4C_11D0_984F_00A024A3D341__INCLUDED_


#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// TagListView.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CTagListView view

class CTagListView : public CListView
{
protected:
	CTagListView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CTagListView)

// Attributes
public:

// Operations
public:
	void SetHeader();
	void AddItem(/*wstring& wszTextString,*/const EventStruct& Event);
	void Clear();   //clears view
	BOOL AddColumn(LPCTSTR strItem,int nItem,int nSubItem=-1,
		int nMask=LVCF_WIDTH|LVCF_TEXT|LVCF_FMT|LVCF_ORDER,int nFmt=LVCFMT_CENTER);
	BOOL AddSubItem(int nSubItem,LPCTSTR strItem,int nItem=0,int nImageIndex=-1);



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTagListView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CTagListView();
	void CleanUp(); //cleans up condition list items

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CTagListView)
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TAGLISTVIEW_H__04D7BE04_FF4C_11D0_984F_00A024A3D341__INCLUDED_)

