// Attribute.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Attribute.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 7 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Attribute.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Attribute.h $
 * 
 * *****************  Version 7  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#if !defined(AFX_ATTRIBUTE_H__CBDE4734_C7E0_11D1_9E05_00608CB8A6B0__INCLUDED_)
#define AFX_ATTRIBUTE_H__CBDE4734_C7E0_11D1_9E05_00608CB8A6B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Attribute.h : header file
//

#include "AttributeMap.h"

/////////////////////////////////////////////////////////////////////////////
// CAttribute dialog

class CAttribute : public CDialog
{
// Construction
public:
	CAttribute(CWnd* pParent = NULL);   // standard constructor
	CAttribute(IOPCEventServerPtr& newIEventServer,IOPCEventSubscriptionMgtPtr& m_ISubMgt,CWnd* pParent = NULL);   // constructor

	void QueryAttributes(DWORD dwEventCategory);
	void SelectReturnedAttrib();
	void GetReturnedAttrib(DWORD dwEventCategory);
	void CurrentAttribList(DWORD dwEventCategory);
	void OnInitEventcombo();





// Dialog Data
	//{{AFX_DATA(CAttribute)
	enum { IDD = IDD_ATTRIBUTE };
	CComboBox	m_EventCombo;
	CListBox	m_AttribList2;
	CListBox	m_EventList;
	CListBox	m_AttribList;
	CString	m_strDwCat;
	CString	m_StrSCat;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAttribute)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	IOPCEventServerPtr m_IEventServer;
	IOPCEventSubscriptionMgtPtr m_ISubMgt;
	EventMap theEventMap;

	// Generated message map functions
	//{{AFX_MSG(CAttribute)
	afx_msg void OnBaddattrib();
	afx_msg void OnBremattrib();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectevent();
	afx_msg void OnSelchangeEventcombo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ATTRIBUTE_H__CBDE4734_C7E0_11D1_9E05_00608CB8A6B0__INCLUDED_)
