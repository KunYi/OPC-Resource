// SampleClientDoc.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: SampleClientDoc.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 31 $
//       $Date: 8/02/02 4:47p $
//    $Archive: /OPC/AlarmEvents/SampleClient/SampleClientDoc.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: SampleClientDoc.cpp $
 * 
 * *****************  Version 31  *****************
 * User: Jiml         Date: 8/02/02    Time: 4:47p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 30  *****************
 * User: Jiml         Date: 11/18/98   Time: 4:28p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Trying for VC5 and VC6 compatibility
 * 
 * *****************  Version 29  *****************
 * User: Jiml         Date: 11/18/98   Time: 3:23p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * Now Builds with VC 6.0
 * 
 * *****************  Version 28  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 27  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// SampleClientDoc.cpp : implementation of the CSampleClientDoc class
//

#include "stdafx.h"
#include "SampleClient.h"

#include "SampleClientDoc.h"
#include "ErrorHandler.h"
#include "GlobalVar.h"
#include "ServerStatus.h" //server status
#include "Common.h"  //common interface
#include "Browser.h" //area and source browsing
#include "Filter.h"  //filter creation
#include "Attribute.h" //attribute selection
#include "EventSub.h"  //event subscription
#include "Connect.h"  //create instance done here
#include "EnableDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

SAFE_EVENT SafeEventStruct;
CSampleClientDoc *theDoc = NULL;

/////////////////////////////////////////////////////////////////////////////
// CSampleClientDoc

IMPLEMENT_DYNCREATE(CSampleClientDoc, CDocument)

BEGIN_MESSAGE_MAP(CSampleClientDoc, CDocument)
	//{{AFX_MSG_MAP(CSampleClientDoc)
	ON_COMMAND(ID_OPC_CONNECT, OnOpcConnect)
	ON_UPDATE_COMMAND_UI(ID_OPC_CONNECT, OnUpdateOpcConnect)
	ON_COMMAND(ID_OPC_DISCONNECT, OnOpcDisconnect)
	ON_UPDATE_COMMAND_UI(ID_OPC_DISCONNECT, OnUpdateOpcDisconnect)
	ON_COMMAND(ID_OPC_GETSTATUS, OnOpcGetstatus)
	ON_UPDATE_COMMAND_UI(ID_OPC_GETSTATUS, OnUpdateOpcGetstatus)
	ON_COMMAND(ID_VIEW_CLEAR_ALL, OnViewClearAll)
	ON_COMMAND(ID_VIEW_CLEAR_LEFT, OnViewClearLeft)
	ON_COMMAND(ID_VIEW_CLEAR_RIGHT, OnViewClearRight)
	ON_COMMAND(ID_OPC_LANGUAGE, OnOpcLanguage)
	ON_UPDATE_COMMAND_UI(ID_OPC_LANGUAGE, OnUpdateOpcLanguage)
	ON_COMMAND(ID_OPC_BROWSER, OnOpcBrowser)
	ON_UPDATE_COMMAND_UI(ID_OPC_BROWSER, OnUpdateOpcBrowser)
	ON_COMMAND(ID_OPC_FILTER, OnOpcFilter)
	ON_UPDATE_COMMAND_UI(ID_OPC_FILTER, OnUpdateOpcFilter)
	ON_COMMAND(ID_OPC_ATTRIBUTES, OnOpcAttributes)
	ON_UPDATE_COMMAND_UI(ID_OPC_ATTRIBUTES, OnUpdateOpcAttributes)
	ON_COMMAND(ID_OPC_EVENTSUB, OnOpcEventsub)
	ON_UPDATE_COMMAND_UI(ID_OPC_EVENTSUB, OnUpdateOpcEventsub)
	ON_COMMAND(ID_OPC_REFRESH, OnOpcRefresh)
	ON_UPDATE_COMMAND_UI(ID_OPC_REFRESH, OnUpdateOpcRefresh)
	ON_COMMAND(ID_OPC_CANCELREFRESH, OnOpcCancelrefresh)
	ON_UPDATE_COMMAND_UI(ID_OPC_CANCELREFRESH, OnUpdateOpcCancelrefresh)
	ON_COMMAND(ID_OPC_TEST, OnOpcTest)
	ON_UPDATE_COMMAND_UI(IDM_ENABLEBYAREA, OnUpdateEnableByArea)
	ON_COMMAND(IDM_ENABLEBYAREA, OnEnableByArea)
	ON_COMMAND(IDM_ENABLESOURCE, OnEnableSource)
	ON_UPDATE_COMMAND_UI(IDM_ENABLESOURCE, OnUpdateEnableSource)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSampleClientDoc construction/destruction

CSampleClientDoc::CSampleClientDoc()
{
	m_bConnected = FALSE;
	m_bSubscription = FALSE;
	theDoc = this;

}

CSampleClientDoc::~CSampleClientDoc()
{
}

BOOL CSampleClientDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSampleClientDoc serialization

void CSampleClientDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSampleClientDoc diagnostics

#ifdef _DEBUG
void CSampleClientDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSampleClientDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSampleClientDoc commands

void CSampleClientDoc::OnOpcConnect() 
{
	CWaitCursor	cWait;		//show wait cursor.

	CConnect dlg;
	dlg.DoModal();	

	m_IEventServer = dlg.m_IEventServer;
	m_IEventServer2 = m_IEventServer;  //  See if we can get the IEventServer2 Interface

	m_bConnected = TRUE;
	m_ISub = NULL;  //initialize smart pointer
}

void CSampleClientDoc::OnUpdateOpcConnect(CCmdUI* pCmdUI) 
{
	SetMenuEventState(pCmdUI,TRUE);
}

void CSampleClientDoc::OnOpcDisconnect() 
{
	CWaitCursor	cWait;		//show wait cursor. 
	HRESULT hr;

	m_bConnected = FALSE;
	m_bSubscription = FALSE;
	
	if(m_ISub != NULL)
	{
		OLE_TRY(hr = AtlUnadvise( m_ISub,__uuidof(IOPCEventSink), m_dwCookie ));
		OLE_TRY(hr = AtlUnadvise( m_ISub,__uuidof(IOPCShutdown), m_dwShutdownCookie ));
		m_ISub.Attach(NULL);
	}

	m_IEventServer2.Attach(NULL);
	m_IEventServer.Attach(NULL);  //detach server
	m_ICommon.Attach(NULL);
	
	OnViewClearAll();
	
}

void CSampleClientDoc::OnUpdateOpcDisconnect(CCmdUI* pCmdUI) 
{
	SetMenuEventState(pCmdUI);
}

void CSampleClientDoc::OnOpcGetstatus() 
{
	CServerStatus dlg(m_IEventServer);
	dlg.DoModal();	
}

void CSampleClientDoc::OnUpdateOpcGetstatus(CCmdUI* pCmdUI) 
{
	SetMenuEventState(pCmdUI);
}


//determines whether functions using an IOPCEventServer smart pointer 
//can be called
void CSampleClientDoc::SetMenuEventState(CCmdUI* pCmdUI,BOOL bConnected) 
{

	if(m_bConnected == bConnected)
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

//determines whether functions using an IOPCEventSubscriptionMgt	 smart pointer 
//can be called
void CSampleClientDoc::SetMenuSubscrState(CCmdUI* pCmdUI,BOOL bSubscription) 
{

	if(	m_bSubscription == bSubscription)
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

void CSampleClientDoc::OnViewClearAll() 
{
	OnViewClearLeft();
	OnViewClearRight();
}

void CSampleClientDoc::OnViewClearLeft() 
{
	pLeftView->Clear();
}

void CSampleClientDoc::OnViewClearRight() 
{
	pRightView->Clear();
}

void CSampleClientDoc::OnOpcLanguage() 
{
	HRESULT hr;
	ADDRIGHT(hr=m_IEventServer->QueryInterface(__uuidof(m_ICommon),(void **)&m_ICommon));
	
	if(hr!= S_OK)
		return;

	COPCCommon dlg(m_ICommon);
	dlg.DoModal();
}

void CSampleClientDoc::OnUpdateOpcLanguage(CCmdUI* pCmdUI) 
{
		SetMenuEventState(pCmdUI);
}

void CSampleClientDoc::OnOpcBrowser() 
{
	CBrowser dlg(m_IEventServer);
	dlg.DoModal();	
}

void CSampleClientDoc::OnUpdateOpcBrowser(CCmdUI* pCmdUI) 
{
		SetMenuEventState(pCmdUI);
}

void CSampleClientDoc::OnOpcFilter() 
{
	CFilter dlg(m_IEventServer,m_ISub);
	dlg.DoModal();
}

void CSampleClientDoc::OnUpdateOpcFilter(CCmdUI* pCmdUI) 
{
		SetMenuSubscrState(pCmdUI);
}

void CSampleClientDoc::OnOpcAttributes() 
{
	CAttribute dlg(m_IEventServer,m_ISub);
	dlg.DoModal();
}

void CSampleClientDoc::OnUpdateOpcAttributes(CCmdUI* pCmdUI) 
{
	SetMenuSubscrState(pCmdUI);
}

void CSampleClientDoc::OnOpcEventsub() 
{
	CEventSub dlg(m_IEventServer,m_ISub);
	dlg.DoModal();

	if(dlg.m_bNewSubscription)
	{
		m_ISub = dlg.m_ISubMgt;   //initialize the document member smart pointer
		m_pSink = dlg.m_pSink;	  //Create advises
		m_dwCookie = dlg.m_dwCookie; //store cookie from creation of advise
	}

	m_bSubscription = TRUE;  //ok here for now
}

void CSampleClientDoc::OnUpdateOpcEventsub(CCmdUI* pCmdUI) 
{
	SetMenuEventState(pCmdUI);
}


void CSampleClientDoc::OnOpcRefresh() 
{
	HRESULT hr;
	
	ADDRIGHT(hr=m_ISub->Refresh(m_dwCookie));
	
}

void CSampleClientDoc::OnUpdateOpcRefresh(CCmdUI* pCmdUI) 
{
	SetMenuSubscrState(pCmdUI);
}

void CSampleClientDoc::OnOpcCancelrefresh() 
{
	HRESULT hr;
	
	ADDRIGHT(hr=m_ISub->CancelRefresh(m_dwCookie));
	
}

void CSampleClientDoc::OnUpdateOpcCancelrefresh(CCmdUI* pCmdUI) 
{
	SetMenuSubscrState(pCmdUI);
}

void CSampleClientDoc::OnOpcTest() 
{
	HRESULT hr;
	ADDRIGHT(hr = m_IEventServer.CreateInstance( L"OPCFoundation.OPCEventServer.1" ));
	if( SUCCEEDED( hr ) )
	{
		// QueryAvailableFilters
		DWORD dwFilters = 0;
		ADDRIGHT(hr = m_IEventServer->QueryAvailableFilters( &dwFilters ));

		DWORD *pdwEventCategories = NULL;;
		LPWSTR *pszDescs = NULL;
		DWORD dwCount = 0;

		// QueryEventCategories
		ADDRIGHT(hr = m_IEventServer->QueryEventCategories( OPC_CONDITION_EVENT, 
								&dwCount, &pdwEventCategories, &pszDescs ));
		for( DWORD i = 0; i < dwCount; i++ )
		{
			TRACE( "%i  %ls\n", pdwEventCategories[i], pszDescs[i] );
			CoTaskMemFree( pszDescs[i] );
		}
		CoTaskMemFree( pdwEventCategories );
		CoTaskMemFree( pszDescs );

		
		// CreateEventSubscription
		long bActive = TRUE;
		DWORD dwBufferTime = 10000;
		DWORD dwMaxSize = 1000;
		DWORD hClientSubscription = (DWORD)this;
		DWORD dwRevisedBuffer = 0;
		DWORD dwRevisedSize = 0;

		ADDRIGHT(hr = m_IEventServer->CreateEventSubscription( bActive,
							dwBufferTime,
							dwMaxSize,
							hClientSubscription,
							GUID_CAST(&__uuidof(m_ISub)),  
                           (IUnknown **)&m_ISub,
						   &dwRevisedBuffer,
						   &dwRevisedSize ));

		ADDRIGHT(hr = m_ISub->GetState( &bActive, &dwBufferTime, &dwMaxSize, &hClientSubscription ));
		


		// create advise
		CComObject<COPCEventSink>::CreateInstance(&m_pSink);
		m_dwCookie = 99;

		ADDRIGHT(hr = AtlAdvise( m_ISub, m_pSink->GetUnknown(),__uuidof(IOPCEventSink), &m_dwCookie ));
		
		ADDRIGHT(hr=m_IEventServer->QueryInterface(__uuidof(m_ICommon),(void **)&m_ICommon));

		//create shutdown advise untested

		CComObject<COPCShutdownRequest>::CreateInstance(&m_pShutdown);
		m_dwShutdownCookie = 98;

		ADDRIGHT(hr = AtlAdvise( m_ISub, m_pShutdown->GetUnknown(),__uuidof(IOPCShutdown), &m_dwShutdownCookie ));
		
			
		// CreateAreaBrowser
		IOPCEventAreaBrowserPtr IBrowse;
		ADDRIGHT(hr = m_IEventServer->CreateAreaBrowser( GUID_CAST(&__uuidof(IBrowse)),  
                           (IUnknown **)&IBrowse ));
	
		::IEnumStringPtr	IString;
		ADDRIGHT(hr=IBrowse->BrowseOPCAreas( OPC_AREA, L"*", &IString ));
		if (hr== S_FALSE) 
		{
			m_bConnected = TRUE;
			UpdateAllViews(NULL);
			return;
		}
			

		dwCount = 1;
		DWORD dwReturned = 0;

		LPOLESTR lpoStr;

		for( hr = IString->Next( dwCount, &lpoStr, &dwReturned );
				dwReturned > 0;
				hr = IString->Next( dwCount, &lpoStr, &dwReturned )	)
		{
			LPWSTR szArea = NULL;
			ADDRIGHT(hr = IBrowse->GetQualifiedAreaName( lpoStr, &szArea ));
			TRACE( "%ls  %ls\n", lpoStr, szArea );
			CoTaskMemFree( lpoStr );
			CoTaskMemFree( szArea );
		}

	}

	m_bConnected = TRUE;
	UpdateAllViews((CView *)pRightView);	
}

void CSampleClientDoc::OnCloseDocument() 
{
	
	OnOpcDisconnect();   // close any open connection

	CDocument::OnCloseDocument();
}

void CSampleClientDoc::OnUpdateEnableByArea(CCmdUI* pCmdUI) 
{
	SetMenuEventState(pCmdUI);
}

void CSampleClientDoc::OnEnableByArea() 
{
	EnableDlg dlg( true );
	dlg.DoModal();
}

void CSampleClientDoc::OnEnableSource() 
{
	EnableDlg dlg( false );
	dlg.DoModal();
}

void CSampleClientDoc::OnUpdateEnableSource(CCmdUI* pCmdUI) 
{
	SetMenuEventState(pCmdUI);
}
