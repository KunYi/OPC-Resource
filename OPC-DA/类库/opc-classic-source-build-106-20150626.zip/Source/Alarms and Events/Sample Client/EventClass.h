// EventClass.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: EventClass.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 5 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/EventClass.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: EventClass.h $
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 4  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#include <vector>
#include "tsQueue.h"

class FileTime : public FILETIME
{
public:
	FileTime& operator =( const FILETIME& ftTime);
	FileTime() {dwLowDateTime = 0; dwHighDateTime = 0;}
	~FileTime() {}
};

inline FileTime& FileTime::operator=( const FILETIME& ftTime )
{
	*((DWORDLONG *)this) = *((DWORDLONG *)(&ftTime));
	return *this;
}

typedef vector<CComVariant> VARIANT_VECTOR;

class EventStruct
{

public:
	EventStruct();
	~EventStruct();
	EventStruct& operator =( const ONEVENTSTRUCT& Event);
	EventStruct& operator =( const EventStruct& Event);


	//ONEVENTSTRUCT variables;
	WORD m_wChangeMask;
	WORD m_wNewState;
	/*LPWSTR*/ wstring m_wszSource;
	FileTime m_ftTime;
	/*LPWSTR*/ wstring m_wszMessage;	
	DWORD m_dwEventType;
	DWORD m_dwEventCategory;
	DWORD m_dwSeverity;
	/*LPWSTR*/ wstring m_wszConditionName;
	/*LPWSTR*/ wstring m_wszSubConditionName;
	WORD m_wQuality;
	BOOL m_bAckRequired;
	FileTime m_ftActiveTime;
	DWORD m_dwCookie;
	DWORD m_dwNumEventAttrs;
	VARIANT_VECTOR m_EventAttributes; //size_is(dwNumEventAttrs)]VARIANT* pEventAttributes
	/*LPWSTR*/ wstring m_wszActorID;

	const CComVariant& operator[](DWORD i) const { return m_EventAttributes[i]; }
};

typedef ThreadSafeQueue< EventStruct > SAFE_EVENT;