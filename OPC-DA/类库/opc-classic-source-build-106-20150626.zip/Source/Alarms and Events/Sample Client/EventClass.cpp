// EventClass.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: EventClass.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 6 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/EventClass.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: EventClass.cpp $
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#include "stdafx.h"
#include "EventClass.h"


// CComVariant GlobalComVariant;

EventStruct::EventStruct()
{
	//ONEVENTSTRUCT variables;
	m_wChangeMask = 0;
	m_wNewState = 0;
	m_wszSource = L"";
	
	m_wszMessage = L"";	
	m_dwEventType = 0;
	m_dwEventCategory = 0;
	m_dwSeverity = 0;
	m_wszConditionName = L"";
	m_wszSubConditionName = L"";
	m_wQuality = 0;
	m_bAckRequired = 0;
	
	m_dwCookie = 0;
	m_dwNumEventAttrs = 0;

	m_wszActorID = L"";
}

EventStruct::~EventStruct()
{

}

EventStruct& EventStruct::operator =( const ONEVENTSTRUCT& Event)
{
	//ONEVENTSTRUCT variables;
	m_wChangeMask = Event.wChangeMask;
	m_wNewState = Event.wNewState;
	m_wszSource = Event.szSource;
	m_ftTime = Event.ftTime;
	m_wszMessage = Event.szMessage;	
	m_dwEventType = Event.dwEventType;
	m_dwEventCategory = Event.dwEventCategory;
	m_dwSeverity = Event.dwSeverity;
	m_wszConditionName = Event.szConditionName;
	m_wszSubConditionName = Event.szSubconditionName;
	m_wQuality = Event.wQuality;
	m_bAckRequired = Event.bAckRequired;
	m_ftActiveTime = Event.ftActiveTime;
	m_dwCookie = Event.dwCookie;
	m_dwNumEventAttrs = Event.dwNumEventAttrs;

	m_EventAttributes.resize( m_dwNumEventAttrs );
	for(DWORD i = 0;i<m_dwNumEventAttrs;i++)
	{
		m_EventAttributes[i] = Event.pEventAttributes[i];
	}
	
	m_wszActorID = Event.szActorID;

	return *this;
}

EventStruct& EventStruct::operator =( const EventStruct& Event)
{
	//ONEVENTSTRUCT variables;
	m_wChangeMask = Event.m_wChangeMask;
	m_wNewState = Event.m_wNewState;
	m_wszSource = Event.m_wszSource;
	m_ftTime = Event.m_ftTime;
	m_wszMessage = Event.m_wszMessage;	
	m_dwEventType = Event.m_dwEventType;
	m_dwEventCategory = Event.m_dwEventCategory;
	m_dwSeverity = Event.m_dwSeverity;
	m_wszConditionName = Event.m_wszConditionName;
	m_wszSubConditionName = Event.m_wszSubConditionName;
	m_wQuality = Event.m_wQuality;
	m_bAckRequired = Event.m_bAckRequired;
	m_ftActiveTime = Event.m_ftActiveTime;
	m_dwCookie = Event.m_dwCookie;
	m_dwNumEventAttrs = Event.m_dwNumEventAttrs;

	m_EventAttributes.resize( m_dwNumEventAttrs );
	for(DWORD i = 0;i<m_dwNumEventAttrs;i++)
		m_EventAttributes[i] = Event.m_EventAttributes[i];
	
	m_wszActorID = Event.m_wszActorID;

	return *this;
}




