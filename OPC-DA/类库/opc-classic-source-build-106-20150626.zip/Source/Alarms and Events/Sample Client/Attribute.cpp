// Attribute.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Attribute.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 8 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Attribute.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Attribute.cpp $
 * 
 * *****************  Version 8  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 7  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// Attribute.cpp : implementation file
//

#include "stdafx.h"
#include "sampleclient.h"
#include "Attribute.h"

//included for error handling
#include "ErrorHandler.h"
#include "GlobalVar.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAttribute dialog

CAttribute::CAttribute(IOPCEventServerPtr& newIEventServer, IOPCEventSubscriptionMgtPtr& newISubMgt,
	CWnd* pParent /*=NULL*/): CDialog(CAttribute::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAttribute)
	m_strDwCat = _T("");
	m_StrSCat = _T("");
	//}}AFX_DATA_INIT

	m_IEventServer = newIEventServer;
	m_ISubMgt = newISubMgt;

}


void CAttribute::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAttribute)
	DDX_Control(pDX, IDC_EVENTCOMBO, m_EventCombo);
	DDX_Control(pDX, IDC_ATTRIBLIST2, m_AttribList2);
	DDX_Control(pDX, IDC_ATTRIBLIST, m_AttribList);
	DDX_Text(pDX, IDC_DWCAT, m_strDwCat);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAttribute, CDialog)
	//{{AFX_MSG_MAP(CAttribute)
	ON_BN_CLICKED(IDC_BADDATTRIB, OnBaddattrib)
	ON_BN_CLICKED(IDC_BREMATTRIB, OnBremattrib)
	ON_CBN_SELCHANGE(IDC_EVENTCOMBO, OnSelchangeEventcombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAttribute message handlers


void CAttribute::OnOK() 
{

	SelectReturnedAttrib();
	
	CDialog::OnOK();
}

BOOL CAttribute::OnInitDialog() 
{
	m_strDwCat = _T("Empty");
	m_StrSCat = _T("Empty");

	CDialog::OnInitDialog();

	OnInitEventcombo();


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

///////////////////////////////////////////
// Event Category support
///////////////////////////////////////////

void CAttribute::OnSelchangeEventcombo() 
{
	USES_CONVERSION;

	int item = 0;
	CString strText;
	DWORD dwEventCategory;

	int index = m_EventCombo.GetCurSel();

	//checks to see if any items are selected
	if(index == CB_ERR)
		return;

	dwEventCategory=m_EventCombo.GetItemData(index);

	WCHAR w[7];

	_ultow(dwEventCategory,w,10);
	m_strDwCat = W2T(w);
	SetDlgItemText(IDC_DWCAT, m_strDwCat);

	m_AttribList.ResetContent();
	m_AttribList2.ResetContent();


	GetReturnedAttrib(dwEventCategory);
	CurrentAttribList(dwEventCategory);
}

void CAttribute::OnInitEventcombo() 
{
	HRESULT hr;

	DWORD *pdwEventCategories = NULL;;
	LPWSTR *pszDescs = NULL;
	DWORD dwCount = 0;

	// QueryEventCategories
	ADDRIGHT(hr = m_IEventServer->QueryEventCategories( OPC_ALL_EVENTS, 
							&dwCount, &pdwEventCategories, &pszDescs ));
	if(hr != S_OK)
		return;

	for( DWORD i = 0; i < dwCount; i++ )
	{
		CString strText(pszDescs[i]);


		int index = m_EventCombo.AddString(strText);
		switch(index)
		{
		case CB_ERR:
			MessageBox("Error Adding Item to Combo Box","Warning",MB_OK|MB_ICONWARNING);							
			break;
		case CB_ERRSPACE:
			MessageBox("Not Enough Memory to Add Item to Combo Box","Warning",MB_OK|MB_ICONWARNING);							
			break;
		default:
			if(m_EventCombo.SetItemData(index,pdwEventCategories[i])==CB_ERR)
				MessageBox("Failed to Set Item Data in Combo Box","Warning",MB_OK|MB_ICONWARNING);							
			break;
		}

		QueryAttributes(pdwEventCategories[i]);  //create an attribute list
		
		CoTaskMemFree( pszDescs[i] );
	}
	
	CoTaskMemFree( pdwEventCategories );
	CoTaskMemFree( pszDescs );

	// select the first item in the combo
	m_EventCombo.SetCurSel( 0 );
	OnSelchangeEventcombo();
	
}


///////////////////////////////////////////
// Attribute support
///////////////////////////////////////////

void CAttribute::CurrentAttribList(DWORD dwEventCategory)
{
	USES_CONVERSION;

	AttributeMap::iterator AttribIt;
	EventMap::iterator EventIt;

	EventIt = theEventMap.find(dwEventCategory);
	if(EventIt == theEventMap.end())
		return;

	for(AttribIt = (*EventIt).second.begin()
		;AttribIt != (*EventIt).second.end()
		;AttribIt++)
	{
		//creating a CString from the wstring in the attribute map
		CString strText(W2T((*AttribIt).second.wszAttrDescs.data()));

		int item = m_AttribList2.AddString(strText);
		if(item == LB_ERR)
			return;
		item = m_AttribList2.SetItemData(item,(*AttribIt).first);
		if(item == LB_ERR)
			return;
	}
}

void CAttribute::SelectReturnedAttrib()
{
	USES_CONVERSION;

	HRESULT hr;
	DWORD dwCount = 0;
	DWORD* pdwAttributeIDs;
	DWORD dwEventCategory;

	//gets total size of list
	UINT count =	m_AttribList.GetCount();
	if(count == LB_ERR)
		return;

	dwCount = count;
	pdwAttributeIDs = new DWORD [dwCount];

	for(UINT i = 0;i< count;i++)
	{
		pdwAttributeIDs[i] = m_AttribList.GetItemData(i);
		if(pdwAttributeIDs[i] == LB_ERR)
			return;

	}

	//converts CString m_strDwCat (string dword category) to DWORD
	WCHAR *w=L" ";
	dwEventCategory = wcstoul(T2W((LPCTSTR)m_strDwCat),&w,10);

	ADDRIGHT(hr=m_ISubMgt->SelectReturnedAttributes(dwEventCategory,dwCount,
		pdwAttributeIDs));

	if(dwCount)
		delete [] pdwAttributeIDs;

}

void CAttribute::GetReturnedAttrib(DWORD dwEventCategory)
{
	USES_CONVERSION;

	HRESULT hr;
	DWORD dwCount;
	DWORD* pdwAttributeIDs;
	
	ADDRIGHT(hr=m_ISubMgt->GetReturnedAttributes(dwEventCategory,&dwCount,
		&pdwAttributeIDs));

	if(hr==S_OK)
	{
		AttributeMap::iterator AttribIt;
		EventMap::iterator EventIt;

		EventIt = theEventMap.find(dwEventCategory);
			if(EventIt == theEventMap.end())
				return;

		for(DWORD i =0;i<dwCount;i++)
		{
			AttribIt = (*EventIt).second.find(pdwAttributeIDs[i]);
			if(AttribIt != (*EventIt).second.end())
			{
				//creating a CString from the wstring in the attribute map
				CString strText(W2T((*AttribIt).second.wszAttrDescs.data()));

				int item = m_AttribList.AddString(strText);
				if(item == LB_ERR)
					return;
				item = m_AttribList.SetItemData(item,pdwAttributeIDs[i]);
				if(item == LB_ERR)
					return;
			}
		}
		CoTaskMemFree(pdwAttributeIDs);
	}


}

void CAttribute::OnBaddattrib() 
{
	int item = 0;
	CString strText;
	DWORD dwEvent;

	UINT count = m_AttribList2.GetSelCount();

	//checks to see if any items are selected
	if(count == 0||count == LB_ERR)
		return;

	//gets total size of list
	count =	m_AttribList2.GetCount();
	if(count == LB_ERR)
		return;

	for(UINT i = 0;i< count;i++)
	{
		item = m_AttribList2.GetSel(i);
		if(item == LB_ERR)
			return;
		else if(item)
		{
			m_AttribList2.GetText(i,strText);
			dwEvent=m_AttribList2.GetItemData(i);

			// no dubplicates in the list
			if( m_AttribList.FindStringExact( 0, strText ) == LB_ERR )
			{
				item = m_AttribList.AddString(strText);
				if(item == LB_ERR)
					return;
				item = m_AttribList.SetItemData(item,dwEvent);
				if(item == LB_ERR)
					return;
			}
		}
	}
}

void CAttribute::OnBremattrib() 
{
	int item = 0;
	UINT count = m_AttribList.GetSelCount();

	//checks to see if any items are selected
	if(count == 0||count == LB_ERR)
		return;

	//gets total size of list
	count =	m_AttribList.GetCount();
	if(count == LB_ERR)
		return;

	//needs to be removed in reverse order.
	for(UINT i = count-1;i >= 0;i--)
	{
		item = m_AttribList.GetSel(i);
		if(item == LB_ERR)  //this will ensure a break from the loop when the number rounds
			return;
		else if(item)
			m_AttribList.DeleteString(i);
	}

}

void CAttribute::QueryAttributes(DWORD dwEventCategory)
{
	HRESULT hr;

	DWORD dwCount;
	DWORD* pdwAttrIDs;
	LPWSTR* pszAttrDescs;
	VARTYPE* pvtAttrTypes;

	ADDRIGHT(hr= m_IEventServer->QueryEventAttributes(dwEventCategory,&dwCount,&pdwAttrIDs
		,&pszAttrDescs,&pvtAttrTypes));

	if(hr==S_OK)
	{
		pair<AttributeMap::iterator, bool> ResultPair;
		pair<EventMap::iterator, bool> EventResultPair;
	
		OPCAttrib Attrib;  //dummy var
		AttributeMap localMap;  //dummy var
		//map is a member of the class so it does not go away until dialog does
		for(DWORD i=0;i<dwCount;i++)
		{
			EventResultPair = theEventMap.insert(EventMap::value_type(dwEventCategory,localMap));
			ResultPair = (*EventResultPair.first).second.insert(AttributeMap::value_type(pdwAttrIDs[i],Attrib));
			(*ResultPair.first).second.wszAttrDescs=pszAttrDescs[i];  //initializes a wstring
			(*ResultPair.first).second.vtAttrTypes=pvtAttrTypes[i];

			CoTaskMemFree(pszAttrDescs[i]);
		}

		CoTaskMemFree(pdwAttrIDs);
		CoTaskMemFree(pszAttrDescs);
		CoTaskMemFree(pvtAttrTypes);
	}

}

