// ErrorHandler.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: ErrorHandler.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 11 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/ErrorHandler.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: ErrorHandler.cpp $
 * 
 * *****************  Version 11  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 10  *****************
 * User: Jiml         Date: 5/19/98    Time: 5:27p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * No longer crashes the compiller when compiled under 95!
 * 
 * *****************  Version 9  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#include "stdafx.h"
#include "ErrorHandler.h"
#include <string> 
using namespace std;

#define MAXSTRSIZE 256
#define ERRBUF 56
#define MAXINPUTSIZE MAXSTRSIZE-ERRBUF

void ComErrorHandler(_com_error e,const char *pFunc,const char * pFile,int iLine)
{
	USES_CONVERSION;


	wstring wszFunctionName(A2W(pFunc));
	wstring wszFileName(A2W(pFile));
	
	TCHAR szTemp[256];
	TCHAR szMsg[1536]; 
	_ftcscpy(szMsg, _T(""));

	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());

	wsprintf(szTemp, _T("Code = %08lx\n"), e.Error());
	_ftcscpy(szMsg, szTemp);
	wsprintf(szTemp, _T("Code meaning = %s\n"), e.ErrorMessage());
	_ftcscat(szMsg, szTemp);    

	wsprintf(szTemp, _T("Source = %s\n"), bstrSource.length() ? (LPCTSTR)bstrSource : _T("null"));
	_ftcscat(szMsg, szTemp);

	wsprintf(szTemp, _T("Description = %s\n"), bstrDescription.length() ? (LPCTSTR)bstrDescription : _T("null"));
	_ftcscat(szMsg, szTemp);

	
	if(wszFunctionName.length() > MAXINPUTSIZE)
		wszFunctionName=wszFunctionName.erase(MAXINPUTSIZE,wszFunctionName.length()-MAXINPUTSIZE);

	wsprintf(szTemp, _T("Function = %lS\n"), wszFunctionName.c_str());
	_ftcscat(szMsg, szTemp);

	if(wszFileName.length() > MAXINPUTSIZE)
		wszFileName=wszFileName.erase(MAXINPUTSIZE,(wszFileName.length()-MAXINPUTSIZE));
	
	wsprintf(szTemp, _T("File = %lS  line number = %d\n"), wszFileName.c_str(),iLine);
	_ftcscat(szMsg, szTemp);
	
	MessageBox(NULL, szMsg, "COM error!", MB_APPLMODAL | MB_ICONHAND);

	TRACE(CString(szMsg) + "!\n");
	
}