// Common.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Common.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 4 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Common.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Common.h $
 * 
 * *****************  Version 4  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 3  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#if !defined(AFX_OPCCOMMON_H__76067994_BE74_11D1_9E03_00608CB8A6B0__INCLUDED_)
#define AFX_OPCCOMMON_H__76067994_BE74_11D1_9E03_00608CB8A6B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// OPCCommon.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COPCCommon dialog

class COPCCommon : public CDialog
{
// Construction
public:
	COPCCommon(IOPCCommonPtr& newCommonPtr,CWnd* pParent = NULL);   // standard constructor
	void GetAvailableID();
	void GetID();



// Dialog Data
	//{{AFX_DATA(COPCCommon)
	enum { IDD = IDD_OPCCOMMON };
	CComboBox	m_IDComboBox;
	CEdit	m_ClientEdit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COPCCommon)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	IOPCCommonPtr m_ICommon;

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COPCCommon)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPCCOMMON_H__76067994_BE74_11D1_9E03_00608CB8A6B0__INCLUDED_)
