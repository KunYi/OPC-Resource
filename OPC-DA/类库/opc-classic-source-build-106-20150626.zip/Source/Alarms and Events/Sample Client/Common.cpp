// Common.cpp
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: Common.cpp $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 6 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/Common.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: Common.cpp $
 * 
 * *****************  Version 6  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
// OPCCommon.cpp : implementation file
//

#include "stdafx.h"
#include "sampleclient.h"
#include "Common.h"

//included for error handling
#include "ErrorHandler.h"
#include "GlobalVar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COPCCommon dialog


COPCCommon::COPCCommon(IOPCCommonPtr& newCommonPtr,CWnd* pParent /*=NULL*/)
	: CDialog(COPCCommon::IDD, pParent)
{
	//{{AFX_DATA_INIT(COPCCommon)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
   m_ICommon=newCommonPtr;  // Get an IOPCCommonPtr interface

}


void COPCCommon::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COPCCommon)
	DDX_Control(pDX, IDC_IDCOMBO, m_IDComboBox);
	DDX_Control(pDX, IDC_CLIENT, m_ClientEdit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COPCCommon, CDialog)
	//{{AFX_MSG_MAP(COPCCommon)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COPCCommon message handlers

BOOL COPCCommon::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	GetID();

	m_ClientEdit.SetWindowText(_T(""));
	m_ClientEdit.SetModify(FALSE);

	GetAvailableID();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COPCCommon::OnOK() 
{
USES_CONVERSION;

	CString szText;
	HRESULT hr;

	if(m_ClientEdit.GetModify())
	{
		
		m_ClientEdit.GetWindowText(szText);
		if(!szText.IsEmpty())
			ADDRIGHT(hr=m_ICommon->SetClientName(A2W(szText)));
	}

	m_IDComboBox.GetWindowText(szText);
	if(!szText.IsEmpty())  //would be 
	{
		LCID dwLcid;
		long ltemp =_ttol((LPCTSTR)szText);
		dwLcid = (DWORD)ltemp;  //convert from signed to unsigned
		if(dwLcid)
			ADDRIGHT(hr=m_ICommon->SetLocaleID(dwLcid));
	}





	
	CDialog::OnOK();
}


void COPCCommon::GetID() 
{
	LCID dwLcid;

	HRESULT hr;

	//get current local ID
	ADDRIGHT(hr=m_ICommon->GetLocaleID(&dwLcid));
	if(hr==S_OK)
	{
		TCHAR t[15];
		wsprintf(t,"%d",dwLcid);
		SetDlgItemText(IDC_CURRENT_ID,t);
	}
	else
	SetDlgItemText(IDC_CURRENT_ID,_T("Error"));
}

void COPCCommon::GetAvailableID() 
{
//code for querying available locale ids
	DWORD dwCount;
	LCID *pdwLcid;
	HRESULT hr;

	ADDRIGHT(hr=m_ICommon->QueryAvailableLocaleIDs(&dwCount,&pdwLcid));
	if(hr==S_OK)
	{
		for(DWORD i=0;i<dwCount;i++)
		{
			TCHAR t[15];
			wsprintf(t,"%d",pdwLcid[i]);
			int index = m_IDComboBox.AddString(t);
		}

	}
	else
 		int index = m_IDComboBox.AddString(_T("Error"));

	CoTaskMemFree(pdwLcid);
}