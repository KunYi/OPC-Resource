// tsQueue.h
//
// � Copyright 1997,1998 The OPC Foundation
// ALL RIGHTS RESERVED.
//
// DISCLAIMER:
//  This sample code is provided by the OPC Foundation solely to assist 
//  in understanding the OPC Alarms and Events Specification and may be used 
//  as set forth in the License Grant section of the OPC Specification.  
//  This code is provided as-is and without warranty or support of any sort 
//  and is subject to the Warranty and Liability Disclaimers which appear 
//  in the printed OPC Specification.
//
// CREDITS:
//  This code was generously provided to the OPC Foundation by 
//  ICONICS, Inc.  http://www.iconics.com
//
// CONTENTS:
//
//  
//-------------------------------------------------------------------------
//
//   $Workfile: tsQueue.h $
//
//
// Org. Author: James Phelps
//     $Author: Jiml $
//   $Revision: 3 $
//       $Date: 8/19/98 2:14p $
//    $Archive: /OPC/AlarmEvents/SampleClient/tsQueue.h $
//
//      System: OPC Alarm & Events
//   Subsystem: 
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: tsQueue.h $
 * 
 * *****************  Version 3  *****************
 * User: Jiml         Date: 8/19/98    Time: 2:14p
 * Updated in $/OPC/AlarmEvents/SampleClient
 * 
 * *****************  Version 2  *****************
 * User: Jiml         Date: 4/23/98    Time: 2:43p
 * Updated in $/OPC/AlarmEvents/SampleClient
*/
//
//
//*************************************************************************          
#ifndef __TSQUEUE_H
#define __TSQUEUE_H

#pragma warning( disable : 4786 )
#include <queue>

using namespace std;


template <class T> class ThreadSafeQueue : public CComAutoCriticalSection
{
private:
	queue<T> m_q;

public:
	void push( const T& x ) { Lock(); m_q.push( x ); Unlock(); }
	bool pop( T& x )
	{
		bool rtn = false;
		Lock();
		if( !m_q.empty() )
		{
			rtn = true;
			x = m_q.front();
			m_q.pop();
		}
		Unlock();
		return rtn;
	}
	bool empty() { Lock(); bool rtn = m_q.empty(); Unlock(); return rtn; }
};




#endif