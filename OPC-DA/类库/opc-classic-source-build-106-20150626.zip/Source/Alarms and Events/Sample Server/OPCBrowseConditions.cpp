//*************************************************************************
//
//   Copyright (c) 1997 OPC FOUNDATION AND ICONICS INC. 
//        (copyrighted as an unpublished work)
//
//-------------------------------------------------------------------------
//
//   $Workfile: OPCBrowseConditions.cpp $
//
//
// Org. Author: Jim Luth
//     $Author: Jiml $
//   $Revision: 5 $
//       $Date: 12/24/97 10:07a $
//    $Archive: /OPC/AlarmEvents/SampleServer/OPCBrowseConditions.cpp $
//
//      System: OPC Alarm & Events
//   Subsystem: Sample Server
//
//
// Description: 
//
// Functions:   
//
//
//
//
//
/*   $History: OPCBrowseConditions.cpp $
 * 
 * *****************  Version 5  *****************
 * User: Jiml         Date: 12/24/97   Time: 10:07a
 * Updated in $/OPC/AlarmEvents/SampleServer
 * 
 * *****************  Version 4  *****************
 * User: Jiml         Date: 12/15/97   Time: 10:45a
 * Updated in $/OPC/AlarmEvents/SampleServer
 * 
 * *****************  Version 3  *****************
 * User: Jiml         Date: 11/24/97   Time: 10:01a
 * Updated in $/OPC/AlarmEvents/SampleServer
 * 
 * *****************  Version 2  *****************
 * User: Jiml         Date: 11/14/97   Time: 6:39p
 * Updated in $/OPC/AlarmEvents/SampleServer
*/
//
//
//*************************************************************************          
// OPCBrowseConditions.cpp : Implementation of COPCBrowseConditions
#include "stdafx.h"
#include "OPC_AE_SampleServer.h"
#include "OPCBrowseConditions.h"

/////////////////////////////////////////////////////////////////////////////
// COPCBrowseConditions

