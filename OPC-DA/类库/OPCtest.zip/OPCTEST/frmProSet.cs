﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using OPCAutomation;
using System.Text.RegularExpressions;
using System.Collections;

namespace OPCTEST
{
    public partial class frmProSet : Form
    {
        //站点代码，站点名称，一级菜单编码，一级菜单名称，二级菜单编码，二级菜单名称
        

        public frmProSet()
        {
            InitializeComponent();
        }

        #region 私有变量
        /// <summary>
        /// OPCServer Object
        /// </summary>
        OPCServer GlobalOPCServer;
        /// <summary>
        /// 主机名称
        /// </summary>
        private string strHostName { get; set; }
        /// <summary>
        /// 连接状态
        /// </summary> 
        private int Scount { get; set; }
        private OPCBrowser objbrow { get; set; }
        DataTable dt = new DataTable();
        #endregion

        //检测
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (Regex.IsMatch(this.toolStripIPText.Text, @"\b(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\b"))
            {
                ping.Ping mPing = new ping.Ping();
                mPing.Pinging(this.toolStripIPText.Text, 1, 1);
                if (mPing.Receive() == true)
                {
                    Scount = 0;
                    try
                    {
                        strHostName = this.toolStripIPText.Text;
                        GlobalOPCServer = new OPCServer();
                        object ServerList = GlobalOPCServer.GetOPCServers(this.toolStripIPText.Text);

                        string[] sa = (string[])ArrayList.Adapter((Array)ServerList).ToArray(typeof(string));
                        for (int i = 0; i < sa.Length; i++)
                        {

                            //comboBox1是一个列表控件 
                            this.toolStripComboBox1.Items.Add(sa[i]);
                            Scount++;
                        }
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("连接远程服务器出现错误：" + err.Message, "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    if (Scount > 0)
                    {
                        MessageBox.Show(this.toolStripIPText.Text + "检测到：" + Scount.ToString() + "个OPC服务");
                        this.toolStripComboBox1.SelectedIndex = 0;
                    }
                }
            }
            else
            {
                MessageBox.Show("IP地址错误,请重新输入");
            }
        }

        private void BuildTree(TreeNode node)
        {
            TreeNode treeNode;
            objbrow.ShowBranches();
            foreach (object Branch in objbrow)
            {
                //添加节点
                treeNode = node.Nodes.Add(Branch.ToString());
                treeNode.Tag = objbrow.GetItemID(Branch.ToString());
                treeNode.ImageIndex = 0;
                treeNode.SelectedImageIndex = 0;
                objbrow.MoveDown(Branch.ToString());
                BuildTree(treeNode);
                //添加叶子
                objbrow.ShowLeafs(false);
                TreeNode subNode;
                foreach (object item in objbrow)
                {
                    subNode = treeNode.Nodes.Add(item.ToString());
                    subNode.Tag = objbrow.GetItemID(item.ToString());
                    subNode.ImageIndex = 1;
                    subNode.SelectedImageIndex = 1;
                }

                objbrow.MoveUp();
            }
        }

        //连接服务器
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (this.toolStripComboBox1.SelectedIndex >= 0 && !String.IsNullOrEmpty(this.toolStripComboBox1.Text))
            {
                GlobalOPCServer.Connect(this.toolStripComboBox1.Text, strHostName);

                if (GlobalOPCServer.ServerState == (int)OPCServerState.OPCRunning)
                {
                    objbrow = GlobalOPCServer.CreateBrowser();
                    this.treeView1.Nodes.Clear();
                    TreeNode RootNode = new TreeNode(this.toolStripComboBox1.Text);
                    this.treeView1.Nodes.Add(RootNode);
                    objbrow.MoveToRoot();
                    BuildTree(RootNode);
                }
                else
                {
                    //这里你可以根据返回的状态来自定义显示信息，请查看自动化接口API文档
                    MessageBox.Show("未连接到服务，状态" + GlobalOPCServer.ServerState.ToString());
                }
            }
        }

        //增加
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(strHostName) || string.IsNullOrEmpty(this.toolStripComboBox1.Text))
                {
                    MessageBox.Show("建立数据集要求连接目标OPC服务器");
                }
                else
                {
                    foreach (TreeNode tn in treeView1.Nodes)
                    {
                        DiGui(tn);
                    }
                }

                this.dataGridView1.DataSource = dt;

                if (dataGridView1.Rows.Count > 0)
                {
                    dataGridView1.Columns[0].Width = 150;
                    dataGridView1.Columns[1].Width = 220;
                    dataGridView1.Columns[2].Width = 570;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("数据操作失败！");
            }
        }

        private void DiGui(TreeNode tn)
        {
            if (tn.Nodes.Count > 0)
            {
                foreach (TreeNode tnSub in tn.Nodes)
                {
                    DiGui(tnSub);
                }
            }
            else
            {
                if (tn.Checked)
                {
                    DataRow[] drs = dt.Select("服务器IP = '" + strHostName + "' and OPC服务 = '" + toolStripComboBox1.Text + "' and 标签 = '" + tn.Tag.ToString() + "'");
                    if (drs.Length <= 0)
                    {
                        DataRow dr = dt.NewRow();
                        dr["服务器IP"] = strHostName;
                        dr["OPC服务"] = toolStripComboBox1.Text;
                        dr["标签"] = tn.Tag.ToString();
                        dt.Rows.Add(dr);
                    }
                }
                else
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        if (dr["服务器IP"].ToString() == strHostName && dr["OPC服务"].ToString() == toolStripComboBox1.Text && dr["标签"].ToString() == tn.Tag.ToString())
                        {
                            dr.Delete();
                        }
                    }
                    dt.AcceptChanges();
                }
            }
        }

        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            CheckControl(e);
        }

        public void CheckControl(TreeViewEventArgs e)
        {
            if (e.Action != TreeViewAction.Unknown)
            {
                if (e.Node != null)
                {
                    CheckParentNode(e.Node, e.Node.Checked);
                }
                if (e.Node.Nodes.Count > 0)
                {
                    CheckAllChildNodes(e.Node, e.Node.Checked);
                }
            }
        }

        //改变所有子节点的状态
        private void CheckAllChildNodes(TreeNode pn, bool IsChecked)
        {
            foreach (TreeNode tn in pn.Nodes)
            {
                tn.Checked = IsChecked;

                if (tn.Nodes.Count > 0)
                {
                    CheckAllChildNodes(tn, IsChecked);
                }
            }
        }

        //改变父节点的选中状态
        private void CheckParentNode(TreeNode curNode, bool IsChecked)
        {
            bool bChecked = true;
            if (curNode.Parent != null)
            {
                foreach (TreeNode node in curNode.Parent.Nodes)
                {
                    if (node.Checked == false)
                    {
                        bChecked = false;
                        break;
                    }
                }
                if (bChecked)
                {
                    curNode.Parent.Checked = true;
                    CheckParentNode(curNode.Parent, true);
                }
                else
                {
                    curNode.Parent.Checked = false;
                    CheckParentNode(curNode.Parent, false);
                }
            }
        }

        //关闭窗体
        private void FormRegSer_FormClosing(object sender, FormClosingEventArgs e)
        {
            //注销OPC服务及连接
            if (GlobalOPCServer != null)
            {
                GlobalOPCServer.Disconnect();
                GlobalOPCServer = null;
            }
        }

        private void frmProSet_Load(object sender, EventArgs e)
        {
            
        }



    }
}
